import { Screen } from "../App";

export default function RekapTunggakanScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-8" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #b45309, #d97706)" }}>
        <button onClick={() => navigate("beranda")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Rekap Kewajiban</h2>
        <p className="text-yellow-100 text-sm mt-1">Memerlukan Perhatian · Aisha VIII-A</p>
      </div>

      <div className="px-5 -mt-3">
        {/* Alert */}
        <div className="bg-orange-50 border border-orange-200 rounded-2xl p-4 mb-4 shadow-sm">
          <div className="flex gap-3">
            <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center flex-none">
              <svg className="w-5 h-5 text-orange-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M12 9v4M12 17h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <p className="font-bold text-orange-800 text-sm">Terdapat 3 kewajiban belum diselesaikan</p>
              <p className="text-orange-700 text-xs mt-1 leading-relaxed">
                Kami memahami setiap keluarga dapat menghadapi kondisi yang berbeda. Silakan tinjau rincian atau jadwalkan konsultasi dengan tata usaha.
              </p>
            </div>
          </div>
        </div>

        {/* Unpaid list */}
        <div className="bg-white rounded-3xl p-4 shadow-sm mb-4">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Rincian Kewajiban Tertunda</h3>
          {[
            { month: "Juni 2026", type: "SPP", amount: "Rp 750.000", overdue: "58 hari", color: "bg-red-100 text-red-700" },
            { month: "Juli 2026", type: "SPP", amount: "Rp 750.000", overdue: "27 hari", color: "bg-orange-100 text-orange-700" },
            { month: "Agustus 2026", type: "SPP", amount: "Rp 750.000", overdue: "3 hari", color: "bg-yellow-100 text-yellow-700" },
          ].map((item) => (
            <div key={item.month} className="flex items-center justify-between py-3 border-b border-gray-50 last:border-0">
              <div>
                <p className="text-sm font-bold text-gray-800">{item.type} {item.month}</p>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${item.color}`}>Terlambat {item.overdue}</span>
              </div>
              <p className="text-sm font-black text-gray-800">{item.amount}</p>
            </div>
          ))}
          <div className="flex justify-between pt-3 mt-1">
            <p className="text-sm font-bold text-gray-600">Total Tertunggak</p>
            <p className="text-base font-black text-orange-700">Rp 2.250.000</p>
          </div>
        </div>

        {/* Info */}
        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-4 mb-4">
          <p className="text-blue-700 text-xs leading-relaxed">
            Keputusan mengenai keringanan, penjadwalan ulang, atau bantuan sepenuhnya menjadi wewenang pihak sekolah. Jadwalkan pertemuan untuk membahas langkah terbaik bersama.
          </p>
        </div>

        <button
          onClick={() => navigate("metode-pembayaran")}
          className="w-full py-3.5 rounded-2xl text-white font-bold text-sm mb-3"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Bayar Sekarang
        </button>

        <button
          onClick={() => navigate("jadwalkan-pertemuan")}
          className="w-full py-3 rounded-2xl border-2 border-orange-300 text-orange-700 font-semibold text-sm">
          Jadwalkan Pertemuan dengan TU
        </button>
      </div>
    </div>
  );
}
