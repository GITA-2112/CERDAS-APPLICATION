import { useState } from "react";
import { Screen } from "../App";

const tagihan = [
  { name: "SPP Agustus 2026", category: "SPP Bulanan", amount: "Rp 750.000", due: "10 Agt 2026", status: "Segera Jatuh Tempo", statusClass: "status-jatuh-tempo", icon: "💳" },
  { name: "Kunjungan Edukasi", category: "Biaya Kegiatan", amount: "Rp 200.000", due: "20 Agt 2026", status: "Mendatang", statusClass: "status-mendatang", icon: "🎒" },
  { name: "Biaya Gedung Sem.1", category: "Biaya Gedung", amount: "Rp 500.000", due: "30 Agt 2026", status: "Mendatang", statusClass: "status-mendatang", icon: "🏫" },
  { name: "SPP Juli 2026", category: "SPP Bulanan", amount: "Rp 750.000", due: "10 Jul 2026", status: "Lunas", statusClass: "status-lunas", icon: "💳" },
  { name: "SPP Juni 2026", category: "SPP Bulanan", amount: "Rp 750.000", due: "10 Jun 2026", status: "Lunas", statusClass: "status-lunas", icon: "💳" },
  { name: "Kemah Pramuka", category: "Biaya Kegiatan", amount: "Rp 350.000", due: "15 Jun 2026", status: "Lunas", statusClass: "status-lunas", icon: "⛺" },
];

const filters = ["Semua", "Belum Bayar", "Lunas"];

export default function DaftarTagihanScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [filter, setFilter] = useState("Semua");

  const filtered = tagihan.filter(t => {
    if (filter === "Belum Bayar") return t.status !== "Lunas";
    if (filter === "Lunas") return t.status === "Lunas";
    return true;
  });

  return (
    <div className="min-h-full pb-6" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <h2 className="text-white font-bold text-xl mb-1">Tagihan</h2>
        <p className="text-purple-200 text-sm">Aisha Nur Fadilah · VIII-A</p>
      </div>

      <div className="px-5 -mt-3">
        <div className="bg-white rounded-2xl p-1 flex gap-1 mb-4 shadow-sm">
          {filters.map(f => (
            <button
              key={f}
              onClick={() => setFilter(f)}
              className={`flex-1 py-2 rounded-xl text-xs font-semibold transition-all ${
                filter === f ? "text-white shadow-sm" : "text-gray-500"
              }`}
              style={filter === f ? { background: "linear-gradient(135deg, #7c3aed, #6d28d9)" } : {}}>
              {f}
            </button>
          ))}
        </div>

        {filtered.map((t) => (
          <button
            key={t.name}
            onClick={() => navigate("rincian-tagihan")}
            className="w-full flex items-center gap-3 bg-white rounded-2xl p-4 mb-3 shadow-sm active:scale-[0.98] transition-all">
            <div className="w-11 h-11 bg-purple-50 rounded-xl flex items-center justify-center text-xl flex-none">
              {t.icon}
            </div>
            <div className="flex-1 text-left">
              <p className="text-sm font-bold text-gray-800">{t.name}</p>
              <p className="text-xs text-gray-500 mt-0.5">{t.category} · Jatuh tempo {t.due}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-bold text-gray-800">{t.amount}</p>
              <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full mt-1 inline-block ${t.statusClass}`}>
                {t.status}
              </span>
            </div>
          </button>
        ))}

        <button
          onClick={() => navigate("ringkasan-semester")}
          className="w-full py-3 rounded-2xl border-2 border-purple-200 text-purple-700 font-semibold text-sm mt-1">
          Lihat Ringkasan Semester
        </button>
      </div>
    </div>
  );
}
