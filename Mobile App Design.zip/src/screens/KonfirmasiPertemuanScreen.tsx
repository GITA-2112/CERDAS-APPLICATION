import { Screen } from "../App";

export default function KonfirmasiPertemuanScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-8 flex flex-col" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-10 flex flex-col items-center"
        style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <div className="mt-6 w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mb-4">
          <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-purple-700" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
              <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" strokeLinecap="round"/>
            </svg>
          </div>
        </div>
        <h2 className="text-white font-black text-xl">Pertemuan Dijadwalkan!</h2>
        <p className="text-purple-200 text-sm mt-1">Konsultasi Keuangan</p>
      </div>

      <div className="px-5 -mt-5">
        <div className="bg-white rounded-3xl p-5 shadow-lg mb-4">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Detail Pertemuan</h3>
          {[
            ["Topik", "Permohonan keringanan"],
            ["Tanggal", "Rabu, 12 Agustus 2026"],
            ["Waktu", "09.00 – 09.30 WIB"],
            ["Metode", "Tatap Muka"],
            ["Lokasi", "Ruang TU, Gedung Utama Lt. 1"],
            ["Petugas", "Bapak Hendra Santoso"],
            ["Status", "Menunggu Konfirmasi TU"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-2 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500">{k}</span>
              <span className={`text-xs font-semibold ${k === "Status" ? "text-yellow-600" : "text-gray-800"}`}>{v}</span>
            </div>
          ))}
        </div>

        <div className="bg-purple-50 border border-purple-100 rounded-2xl p-4 mb-4">
          <p className="text-purple-700 text-xs leading-relaxed">
            Anda akan menerima notifikasi konfirmasi dari tata usaha dalam 1×24 jam kerja. Jika ada perubahan, silakan hubungi kami melalui WhatsApp sekolah.
          </p>
        </div>

        <div className="flex gap-3 mb-3">
          <button className="flex-1 py-3 bg-purple-100 rounded-2xl text-purple-700 font-semibold text-xs flex items-center justify-center gap-1.5">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <rect x="3" y="4" width="18" height="18" rx="2"/>
              <path d="M16 2v4M8 2v4M3 10h18" strokeLinecap="round"/>
            </svg>
            Tambah ke Kalender
          </button>
          <button className="flex-1 py-3 bg-gray-100 rounded-2xl text-gray-600 font-semibold text-xs">
            Ubah Jadwal
          </button>
        </div>

        <button
          onClick={() => navigate("beranda")}
          className="w-full py-3.5 rounded-2xl text-white font-bold text-sm"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Kembali ke Beranda
        </button>

        <button
          onClick={() => navigate("rekap-tunggakan")}
          className="w-full py-3 text-red-500 text-xs font-semibold mt-3">
          Batalkan Pertemuan
        </button>
      </div>
    </div>
  );
}
