import { useState } from "react";
import { Screen } from "../App";

const days = ["Min", "Sen", "Sel", "Rab", "Kam", "Jum", "Sab"];
const events: Record<number, { label: string; color: string }> = {
  10: { label: "SPP", color: "bg-yellow-400" },
  15: { label: "UTS", color: "bg-blue-400" },
  20: { label: "Kunjungan", color: "bg-blue-400" },
  30: { label: "Gedung", color: "bg-purple-400" },
};

export default function KalenderScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [selected, setSelected] = useState<number | null>(10);

  return (
    <div className="min-h-full pb-6" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <h2 className="text-white font-bold text-xl mb-1">Kalender Pembayaran</h2>
        <p className="text-purple-200 text-sm">Agustus 2026</p>
      </div>

      <div className="px-5 -mt-3">
        {/* Calendar */}
        <div className="bg-white rounded-3xl p-4 shadow-sm mb-4">
          <div className="flex items-center justify-between mb-4">
            <button className="w-8 h-8 bg-gray-100 rounded-xl flex items-center justify-center">
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <path d="M15 19l-7-7 7-7" strokeLinecap="round"/>
              </svg>
            </button>
            <p className="font-bold text-gray-800">Agustus 2026</p>
            <button className="w-8 h-8 bg-gray-100 rounded-xl flex items-center justify-center">
              <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                <path d="M9 5l7 7-7 7" strokeLinecap="round"/>
              </svg>
            </button>
          </div>

          <div className="grid grid-cols-7 mb-2">
            {days.map(d => (
              <div key={d} className="text-center text-[10px] font-semibold text-gray-400 py-1">{d}</div>
            ))}
          </div>

          <div className="grid grid-cols-7 gap-y-1">
            {/* Offset: Aug 1 2026 is Saturday (6) */}
            {Array.from({ length: 6 }, (_, i) => (
              <div key={`e-${i}`}/>
            ))}
            {Array.from({ length: 31 }, (_, i) => {
              const day = i + 1;
              const event = events[day];
              const isSelected = selected === day;
              const isToday = day === 7;
              return (
                <button
                  key={day}
                  onClick={() => setSelected(day)}
                  className={`relative flex flex-col items-center py-1 rounded-xl transition-all
                    ${isSelected ? "text-white" : isToday ? "text-purple-700 font-bold" : "text-gray-700"}`}
                  style={isSelected ? { background: "linear-gradient(135deg, #7c3aed, #6d28d9)" } : {}}
                >
                  <span className="text-xs font-medium">{day}</span>
                  {event && (
                    <div className={`w-1.5 h-1.5 rounded-full mt-0.5 ${isSelected ? "bg-white" : event.color}`}/>
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-2 mb-4">
          {[
            { color: "bg-green-400", label: "Lunas" },
            { color: "bg-purple-400", label: "Mendatang" },
            { color: "bg-yellow-400", label: "Jatuh Tempo" },
            { color: "bg-orange-400", label: "Terlambat" },
            { color: "bg-blue-400", label: "Agenda" },
          ].map(({ color, label }) => (
            <div key={label} className="flex items-center gap-1.5 bg-white rounded-xl px-2.5 py-1.5 shadow-sm">
              <div className={`w-2 h-2 rounded-full ${color}`}/>
              <span className="text-[10px] font-medium text-gray-600">{label}</span>
            </div>
          ))}
        </div>

        {/* Event detail */}
        {selected && (
          <div className="bg-white rounded-3xl p-4 shadow-sm slide-up">
            <p className="text-xs text-gray-400 mb-3">
              {selected} Agustus 2026
            </p>
            {selected === 10 && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-yellow-100 rounded-xl flex items-center justify-center text-lg flex-none">💳</div>
                <div className="flex-1">
                  <p className="font-bold text-gray-800 text-sm">SPP Agustus 2026</p>
                  <p className="text-xs text-gray-500 mt-0.5">Jatuh tempo hari ini · Rp 750.000</p>
                  <span className="inline-block bg-yellow-100 text-yellow-700 text-[10px] font-bold px-2 py-0.5 rounded-full mt-1.5">Segera Jatuh Tempo</span>
                </div>
              </div>
            )}
            {selected === 20 && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-lg flex-none">🎒</div>
                <div className="flex-1">
                  <p className="font-bold text-gray-800 text-sm">Kunjungan Edukasi Sem. Ganjil</p>
                  <p className="text-xs text-gray-500 mt-0.5">Biaya kegiatan · Rp 200.000</p>
                  <p className="text-xs text-blue-600 mt-1">Disepakati Komite Sekolah 15 Jul 2026</p>
                </div>
              </div>
            )}
            {(selected === 15) && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center text-lg flex-none">📝</div>
                <div className="flex-1">
                  <p className="font-bold text-gray-800 text-sm">Ujian Tengah Semester</p>
                  <p className="text-xs text-gray-500 mt-0.5">Agenda sekolah · Tidak ada biaya</p>
                </div>
              </div>
            )}
            {(selected === 30) && (
              <div className="flex items-start gap-3">
                <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center text-lg flex-none">🏫</div>
                <div className="flex-1">
                  <p className="font-bold text-gray-800 text-sm">Biaya Gedung Semester 1</p>
                  <p className="text-xs text-gray-500 mt-0.5">Jatuh tempo · Rp 500.000</p>
                </div>
              </div>
            )}
            {![10,15,20,30].includes(selected) && (
              <p className="text-gray-400 text-sm text-center py-2">Tidak ada agenda</p>
            )}
            {[10, 20, 30].includes(selected) && (
              <div className="flex gap-2 mt-3">
                <button onClick={() => navigate("rincian-tagihan")} className="flex-1 py-2 bg-gray-50 rounded-xl text-xs font-semibold text-gray-700">Lihat Rincian</button>
                <button onClick={() => navigate("metode-pembayaran")} className="flex-1 py-2 rounded-xl text-white text-xs font-semibold" style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>Bayar Sekarang</button>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
