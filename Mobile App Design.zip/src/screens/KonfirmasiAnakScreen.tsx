import { Screen } from "../App";

export default function KonfirmasiAnakScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full bg-white flex flex-col">
      <div className="px-6 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("konfirmasi-ortu")} className="text-white/80 mb-6 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="text-sm">Kembali</span>
        </button>
        <h2 className="text-white font-bold text-xl">Profil Anak</h2>
        <p className="text-purple-200 text-sm mt-1">Konfirmasi data anak yang terdaftar</p>
      </div>

      <div className="flex-1 px-6 pt-6 pb-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-2xl overflow-hidden bg-purple-100 flex items-center justify-center">
            <img
              src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=100&h=100&fit=crop&auto=format"
              alt="Foto Aisha"
              className="w-full h-full object-cover"
            />
          </div>
          <div>
            <p className="font-bold text-gray-800 text-lg">Aisha Nur Fadilah</p>
            <span className="bg-green-100 text-green-700 text-xs font-semibold px-2.5 py-1 rounded-full">Siswa Aktif</span>
          </div>
        </div>

        {[
          { label: "Nomor Induk Siswa", value: "2024.001.0342" },
          { label: "Kelas", value: "VIII-A" },
          { label: "Tahun Ajaran", value: "2026/2027" },
          { label: "Status Pembiayaan", value: "Umum" },
          { label: "Kewajiban Berlaku", value: "SPP, Biaya Gedung, Kegiatan" },
        ].map(({ label, value }) => (
          <div key={label} className="mb-4">
            <label className="text-xs text-gray-500 font-medium block mb-1">{label}</label>
            <div className="bg-gray-50 border border-gray-200 rounded-xl px-4 py-3">
              <span className="text-sm font-medium text-gray-800">{value}</span>
            </div>
          </div>
        ))}

        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 mb-6">
          <p className="text-purple-700 text-xs font-medium">
            Jika terdapat data yang tidak sesuai, silakan hubungi tata usaha sekolah untuk perbaikan.
          </p>
        </div>

        <button
          onClick={() => navigate("beranda")}
          className="w-full py-3.5 rounded-2xl text-white font-semibold text-sm"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Konfirmasi dan Mulai
        </button>
      </div>
    </div>
  );
}
