import { useState } from "react";
import { Screen } from "../App";

const banks = [
  { name: "BCA", va: "8001234567890001", color: "bg-blue-700" },
  { name: "BRI", va: "8890001234567890", color: "bg-sky-600" },
  { name: "Mandiri", va: "8990001234567890", color: "bg-yellow-500" },
  { name: "BNI", va: "8800001234567890", color: "bg-orange-600" },
];

export default function VirtualAccountScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [selected, setSelected] = useState(banks[0]);
  const [copied, setCopied] = useState(false);

  const copy = () => {
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="min-h-full bg-white flex flex-col">
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("metode-pembayaran")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Transfer Virtual Account</h2>
        <p className="text-purple-200 text-sm">Pilih bank dan salin nomor VA</p>
      </div>

      <div className="flex-1 px-5 pt-5 pb-8">
        <p className="text-xs text-gray-500 font-semibold mb-3">Pilih Bank</p>
        <div className="grid grid-cols-4 gap-2 mb-5">
          {banks.map((bank) => (
            <button
              key={bank.name}
              onClick={() => setSelected(bank)}
              className={`py-3 rounded-xl border-2 transition-all text-sm font-bold text-white
                ${selected.name === bank.name ? "border-purple-500 scale-105" : "border-transparent opacity-80"}
                ${bank.color}`}>
              {bank.name}
            </button>
          ))}
        </div>

        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 mb-4">
          <p className="text-xs text-gray-500 mb-1">Nomor Virtual Account {selected.name}</p>
          <div className="flex items-center justify-between">
            <p className="text-lg font-black text-purple-800 tracking-wider">{selected.va}</p>
            <button
              onClick={copy}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${copied ? "bg-green-500 text-white" : "bg-purple-600 text-white"}`}>
              {copied ? "✓ Tersalin" : "Salin"}
            </button>
          </div>
        </div>

        <div className="bg-white border border-gray-100 rounded-2xl p-4 mb-4 shadow-sm">
          <div className="flex justify-between mb-2">
            <span className="text-xs text-gray-500">Total Pembayaran</span>
            <span className="text-base font-black text-purple-700">Rp 750.000</span>
          </div>
          <div className="flex justify-between">
            <span className="text-xs text-gray-500">Batas Waktu</span>
            <span className="text-xs font-semibold text-orange-600">10 Agustus 2026, 23:59</span>
          </div>
        </div>

        <div className="bg-gray-50 rounded-2xl p-4 mb-5">
          <p className="text-xs font-semibold text-gray-700 mb-2">Cara Transfer:</p>
          {[
            "Login internet banking atau buka ATM",
            "Pilih Transfer → Virtual Account",
            "Masukkan nomor VA yang tertera",
            "Konfirmasi jumlah: Rp 750.000",
            "Selesaikan transaksi",
          ].map((step, i) => (
            <div key={i} className="flex items-start gap-2.5 mb-1.5 last:mb-0">
              <div className="w-4 h-4 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center text-[9px] font-bold flex-none">{i+1}</div>
              <p className="text-xs text-gray-600">{step}</p>
            </div>
          ))}
        </div>

        <button
          onClick={() => navigate("pembayaran-berhasil")}
          className="w-full py-3.5 rounded-2xl text-white font-bold text-sm"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Simulasi: Konfirmasi Pembayaran
        </button>
      </div>
    </div>
  );
}
