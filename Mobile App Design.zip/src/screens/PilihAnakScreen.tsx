import { Screen } from "../App";

const children = [
  { name: "Aisha Nur Fadilah", nis: "2024.001.0342", kelas: "VIII-A", photo: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=80&h=80&fit=crop&auto=format", status: "Aktif", unpaid: "Rp 750.000" },
  { name: "Rizky Firmansyah", nis: "2026.001.0118", kelas: "VI-B (SD)", photo: "https://images.unsplash.com/photo-1545558014-8692077e9b5c?w=80&h=80&fit=crop&auto=format", status: "Aktif", unpaid: "Rp 0" },
];

export default function PilihAnakScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full bg-white">
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("beranda")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Pilih Profil Anak</h2>
        <p className="text-purple-200 text-sm">2 anak terdaftar</p>
      </div>

      <div className="px-5 pt-5">
        {children.map((child) => (
          <button
            key={child.nis}
            onClick={() => navigate("beranda")}
            className="w-full flex items-center gap-4 p-4 bg-white border border-gray-100 rounded-2xl mb-3 shadow-sm active:scale-[0.98] transition-all">
            <div className="w-14 h-14 rounded-2xl overflow-hidden bg-purple-100 flex-none">
              <img src={child.photo} alt={child.name} className="w-full h-full object-cover"/>
            </div>
            <div className="flex-1 text-left">
              <p className="font-bold text-gray-800">{child.name}</p>
              <p className="text-gray-500 text-xs mt-0.5">NIS: {child.nis} • {child.kelas}</p>
              <div className="flex items-center gap-2 mt-1.5">
                <span className="bg-green-100 text-green-700 text-[10px] font-semibold px-2 py-0.5 rounded-full">{child.status}</span>
                {child.unpaid !== "Rp 0" && (
                  <span className="bg-orange-100 text-orange-700 text-[10px] font-semibold px-2 py-0.5 rounded-full">Belum bayar: {child.unpaid}</span>
                )}
                {child.unpaid === "Rp 0" && (
                  <span className="bg-green-100 text-green-700 text-[10px] font-semibold px-2 py-0.5 rounded-full">Lunas ✓</span>
                )}
              </div>
            </div>
            <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M9 18l6-6-6-6" strokeLinecap="round"/>
            </svg>
          </button>
        ))}
      </div>
    </div>
  );
}
