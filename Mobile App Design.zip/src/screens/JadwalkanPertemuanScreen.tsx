import { useState } from "react";
import { Screen } from "../App";

const topics = [
  "Klarifikasi tagihan",
  "Konfirmasi pembayaran",
  "Permohonan keringanan",
  "Informasi beasiswa/bantuan",
  "Pembayaran tunai",
  "Kendala lainnya",
];

export default function JadwalkanPertemuanScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [topic, setTopic] = useState("");
  const [method, setMethod] = useState<"online" | "offline">("offline");
  const [time, setTime] = useState("09.00");
  const [date, setDate] = useState("12");

  return (
    <div className="min-h-full bg-white flex flex-col">
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("rekap-tunggakan")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Jadwalkan Pertemuan</h2>
        <p className="text-purple-200 text-sm">Konsultasi dengan Tata Usaha</p>
      </div>

      <div className="flex-1 px-5 pt-5 pb-8">
        {/* Topic */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-gray-700 mb-2 block">Topik Pertemuan</label>
          <div className="grid grid-cols-2 gap-2">
            {topics.map((t) => (
              <button
                key={t}
                onClick={() => setTopic(t)}
                className={`py-2.5 px-3 rounded-xl border text-xs font-medium text-left transition-all
                  ${topic === t ? "border-purple-500 bg-purple-50 text-purple-700" : "border-gray-200 bg-gray-50 text-gray-600"}`}>
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Date */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-gray-700 mb-2 block">Tanggal (Agustus 2026)</label>
          <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
            {["11","12","13","14","15","18","19"].map((d) => (
              <button
                key={d}
                onClick={() => setDate(d)}
                className={`flex-none w-10 h-12 rounded-xl text-sm font-bold transition-all
                  ${date === d ? "text-white" : "bg-gray-100 text-gray-600"}`}
                style={date === d ? { background: "linear-gradient(135deg, #7c3aed, #6d28d9)" } : {}}>
                {d}
              </button>
            ))}
          </div>
        </div>

        {/* Time */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-gray-700 mb-2 block">Waktu</label>
          <div className="grid grid-cols-4 gap-2">
            {["08.00","09.00","10.00","13.00","14.00"].map((t) => (
              <button
                key={t}
                onClick={() => setTime(t)}
                className={`py-2 rounded-xl text-xs font-semibold transition-all
                  ${time === t ? "text-white" : "bg-gray-100 text-gray-600"}`}
                style={time === t ? { background: "linear-gradient(135deg, #7c3aed, #6d28d9)" } : {}}>
                {t}
              </button>
            ))}
          </div>
        </div>

        {/* Method */}
        <div className="mb-4">
          <label className="text-xs font-semibold text-gray-700 mb-2 block">Metode Pertemuan</label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { val: "offline" as const, label: "Tatap Muka", icon: "🏫" },
              { val: "online" as const, label: "Daring (Video Call)", icon: "💻" },
            ].map(({ val, label, icon }) => (
              <button
                key={val}
                onClick={() => setMethod(val)}
                className={`py-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition-all
                  ${method === val ? "border-purple-500 bg-purple-50 text-purple-700" : "border-gray-200 bg-gray-50 text-gray-600"}`}>
                <span>{icon}</span>{label}
              </button>
            ))}
          </div>
          {method === "offline" && (
            <div className="mt-2 bg-gray-50 rounded-xl p-3">
              <p className="text-xs text-gray-600">📍 Ruang Tata Usaha, Gedung Utama Lt. 1</p>
              <p className="text-xs text-gray-500 mt-0.5">SMP Negeri 5 Jakarta</p>
            </div>
          )}
        </div>

        {/* Notes */}
        <div className="mb-5">
          <label className="text-xs font-semibold text-gray-700 mb-2 block">Catatan (opsional)</label>
          <div className="bg-gray-50 border border-gray-200 rounded-xl px-3 py-3 text-xs text-gray-400">
            Tuliskan hal yang ingin disampaikan...
          </div>
        </div>

        <button
          onClick={() => navigate("konfirmasi-pertemuan")}
          className="w-full py-3.5 rounded-2xl text-white font-bold text-sm"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Konfirmasi Jadwal
        </button>
      </div>
    </div>
  );
}
