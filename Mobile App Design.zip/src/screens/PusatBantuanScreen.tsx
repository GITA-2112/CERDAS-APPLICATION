import { useState } from "react";
import { Screen } from "../App";

const faqs = [
  { q: "Bagaimana cara melakukan pembayaran?", a: "Anda dapat membayar melalui QRIS, transfer Virtual Account, atau tunai di tata usaha. Pilih 'Bayar Sekarang' pada tagihan yang ingin dibayar." },
  { q: "Kapan tagihan SPP diterbitkan?", a: "Tagihan SPP diterbitkan otomatis pada tanggal 1 setiap bulan dan jatuh tempo pada tanggal 10." },
  { q: "Bagaimana jika ada kesalahan pada tagihan?", a: "Silakan hubungi tata usaha melalui jadwal pertemuan atau WhatsApp sekolah untuk klarifikasi." },
  { q: "Apakah invoice dapat diunduh?", a: "Ya, invoice resmi dapat diunduh dalam format PDF setelah pembayaran berhasil diverifikasi." },
  { q: "Bagaimana cara menjadwalkan pertemuan?", a: "Buka menu Tagihan → pilih tagihan → Hubungi Tata Usaha, atau langsung melalui menu Jadwalkan Pertemuan." },
];

export default function PusatBantuanScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [open, setOpen] = useState<number | null>(null);

  return (
    <div className="min-h-full pb-8" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("profil")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Pusat Bantuan</h2>
        <p className="text-purple-200 text-sm">Ada yang bisa kami bantu?</p>
      </div>

      <div className="px-5 pt-4">
        {/* Quick actions */}
        <div className="grid grid-cols-2 gap-3 mb-5">
          {[
            { icon: "💬", label: "Chat WhatsApp", color: "bg-green-50 border-green-100" },
            { icon: "📞", label: "Hubungi Sekolah", color: "bg-blue-50 border-blue-100" },
            { icon: "📅", label: "Jadwal Pertemuan", color: "bg-purple-50 border-purple-100", action: () => navigate("jadwalkan-pertemuan") },
            { icon: "✉️", label: "Kirim Pesan", color: "bg-orange-50 border-orange-100" },
          ].map(({ icon, label, color, action }) => (
            <button
              key={label}
              onClick={action}
              className={`p-4 rounded-2xl border ${color} flex flex-col items-center gap-2 active:scale-[0.97] transition-all`}>
              <span className="text-2xl">{icon}</span>
              <span className="text-xs font-semibold text-gray-700">{label}</span>
            </button>
          ))}
        </div>

        {/* FAQ */}
        <div className="bg-white rounded-3xl p-4 shadow-sm">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Pertanyaan Umum</h3>
          {faqs.map((faq, i) => (
            <div key={i} className="border-b border-gray-50 last:border-0">
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between py-3">
                <p className="text-xs font-semibold text-gray-800 text-left flex-1 pr-2">{faq.q}</p>
                <svg
                  className={`w-4 h-4 text-gray-400 flex-none transition-transform ${open === i ? "rotate-180" : ""}`}
                  fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                  <path d="M19 9l-7 7-7-7" strokeLinecap="round"/>
                </svg>
              </button>
              {open === i && (
                <div className="pb-3">
                  <p className="text-xs text-gray-500 leading-relaxed">{faq.a}</p>
                </div>
              )}
            </div>
          ))}
        </div>

        <div className="bg-purple-50 border border-purple-100 rounded-2xl p-4 mt-4 text-center">
          <p className="text-xs text-purple-700 font-medium mb-1">Jam Layanan Tata Usaha</p>
          <p className="text-xs text-purple-600">Senin – Kamis: 07.30 – 14.30 WIB</p>
          <p className="text-xs text-purple-600">Jumat: 07.30 – 11.30 WIB</p>
          <p className="text-[10px] text-purple-400 mt-1">WhatsApp Sekolah: +62 811-2345-6789</p>
        </div>
      </div>
    </div>
  );
}
