import { Screen } from "../App";

export default function ActivasiScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full flex flex-col" style={{ background: "linear-gradient(180deg, #f5f3ff 0%, #fff 40%)" }}>
      {/* Header illustration */}
      <div className="relative pt-8 pb-6 flex flex-col items-center"
        style={{ background: "linear-gradient(160deg, #6d28d9 0%, #7c3aed 60%, #8b5cf6 100%)" }}>
        <div className="w-20 h-20 bg-white/20 rounded-3xl flex items-center justify-center mb-4">
          <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center">
            <span className="text-3xl font-black text-purple-700">C</span>
          </div>
        </div>
        <h1 className="text-white font-bold text-xl">Selamat Datang</h1>
        <p className="text-purple-200 text-sm mt-1">di CERDAS Sekolah</p>
        <div className="absolute bottom-0 left-0 right-0 h-8 bg-white" style={{ borderRadius: "32px 32px 0 0" }}/>
      </div>

      <div className="flex-1 px-6 pt-2 pb-8">
        <h2 className="text-xl font-bold text-gray-800 mb-1">Aktivasi Akun</h2>
        <p className="text-gray-500 text-sm mb-6">
          Masukkan nomor WhatsApp yang terdaftar untuk menerima tautan aktivasi dari sekolah.
        </p>

        {/* Notification card */}
        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 mb-6 flex gap-3">
          <div className="w-8 h-8 bg-purple-100 rounded-xl flex items-center justify-center flex-none">
            <svg className="w-4 h-4 text-purple-700" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeLinecap="round"/>
            </svg>
          </div>
          <p className="text-purple-700 text-xs leading-relaxed">
            Akun Anda dibuat oleh tata usaha sekolah setelah anak Anda resmi terdaftar. Hubungi sekolah jika belum menerima aktivasi.
          </p>
        </div>

        <div className="mb-5">
          <label className="text-sm font-semibold text-gray-700 mb-2 block">Nomor WhatsApp</label>
          <div className="flex gap-2">
            <div className="bg-gray-50 border border-gray-200 rounded-xl px-3 flex items-center">
              <span className="text-sm font-medium text-gray-700">+62</span>
            </div>
            <div className="flex-1 bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-400">
              812-3456-7890
            </div>
          </div>
        </div>

        <button
          onClick={() => navigate("otp")}
          className="w-full py-3.5 rounded-2xl text-white font-semibold text-sm transition-all active:scale-[0.98]"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Kirim Kode OTP
        </button>

        <div className="mt-4 text-center">
          <p className="text-gray-400 text-xs">
            Belum menerima aktivasi?{" "}
            <span className="text-purple-600 font-semibold">Hubungi Tata Usaha</span>
          </p>
        </div>
      </div>
    </div>
  );
}
