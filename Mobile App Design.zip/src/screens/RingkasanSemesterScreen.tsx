import { Screen } from "../App";

export default function RingkasanSemesterScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-6" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-10 rounded-b-[36px]"
        style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("beranda")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Kewajiban Semester Ganjil</h2>
        <p className="text-purple-200 text-sm">Tahun Ajaran 2026/2027 · Aisha VIII-A</p>
        <div className="bg-white/15 backdrop-blur rounded-2xl p-4 mt-4">
          <p className="text-white/70 text-xs mb-1">Total Kewajiban Semester</p>
          <p className="text-white font-bold text-3xl">Rp 5.950.000</p>
          <div className="flex gap-4 mt-3">
            <div>
              <p className="text-white/70 text-xs">Sudah Dibayar</p>
              <p className="text-green-300 font-bold text-sm">Rp 3.600.000</p>
            </div>
            <div>
              <p className="text-white/70 text-xs">Sisa</p>
              <p className="text-yellow-300 font-bold text-sm">Rp 2.350.000</p>
            </div>
          </div>
          <div className="mt-3 bg-white/20 rounded-full h-2">
            <div className="bg-green-400 h-2 rounded-full" style={{ width: "60%" }}/>
          </div>
          <p className="text-white/60 text-xs mt-1">60% terbayar</p>
        </div>
      </div>

      <div className="px-5 -mt-4">
        <div className="bg-white rounded-3xl p-4 shadow-sm mb-4">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Rincian Kewajiban</h3>
          {[
            { name: "SPP Bulanan (6 bulan)", amount: "Rp 4.500.000", paid: 3, total: 6, color: "bg-purple-500" },
            { name: "Biaya Kegiatan", amount: "Rp 950.000", paid: 1, total: 2, color: "bg-blue-500" },
            { name: "Biaya Gedung", amount: "Rp 500.000", paid: 0, total: 1, color: "bg-orange-500" },
          ].map((item) => (
            <div key={item.name} className="py-3 border-b border-gray-50 last:border-0">
              <div className="flex justify-between mb-1.5">
                <p className="text-sm font-semibold text-gray-800">{item.name}</p>
                <p className="text-sm font-bold text-gray-800">{item.amount}</p>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex-1 bg-gray-100 rounded-full h-1.5">
                  <div className={`${item.color} h-1.5 rounded-full`} style={{ width: `${(item.paid/item.total)*100}%` }}/>
                </div>
                <p className="text-xs text-gray-500">{item.paid}/{item.total} terbayar</p>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-3xl p-4 shadow-sm mb-4">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Kalender Jatuh Tempo</h3>
          {[
            { month: "Agustus 2026", items: ["SPP Agustus – 10 Agt", "Kunjungan Edukasi – 20 Agt", "Biaya Gedung – 30 Agt"], color: "bg-yellow-400" },
            { month: "September 2026", items: ["SPP September – 10 Sep"], color: "bg-purple-400" },
          ].map((m) => (
            <div key={m.month} className="mb-3 last:mb-0">
              <div className="flex items-center gap-2 mb-2">
                <div className={`w-2 h-2 rounded-full ${m.color}`}/>
                <p className="text-xs font-semibold text-gray-600">{m.month}</p>
              </div>
              {m.items.map((item) => (
                <p key={item} className="text-xs text-gray-500 ml-4 mb-1">• {item}</p>
              ))}
            </div>
          ))}
        </div>

        <button
          onClick={() => navigate("daftar-tagihan")}
          className="w-full py-3.5 rounded-2xl text-white font-semibold text-sm"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Lihat Semua Tagihan
        </button>
      </div>
    </div>
  );
}
