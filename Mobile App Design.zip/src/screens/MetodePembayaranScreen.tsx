import { Screen } from "../App";

export default function MetodePembayaranScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const methods = [
    {
      id: "qris",
      icon: "▦",
      title: "QRIS",
      desc: "Scan QR dengan aplikasi dompet digital",
      badge: "Instan",
      screen: "qris" as Screen,
    },
    {
      id: "va",
      icon: "🏦",
      title: "Transfer Virtual Account",
      desc: "Transfer via internet banking atau ATM",
      badge: "1×24 jam",
      screen: "virtual-account" as Screen,
    },
    {
      id: "cash",
      icon: "💵",
      title: "Tunai — Tata Usaha",
      desc: "Bayar langsung di kantor administrasi",
      badge: "Hari kerja",
      screen: "tunai" as Screen,
    },
  ];

  return (
    <div className="min-h-full bg-white flex flex-col">
      <div className="px-5 pt-4 pb-8" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("rincian-tagihan")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Metode Pembayaran</h2>
        <p className="text-purple-200 text-sm mt-1">SPP Agustus 2026 · Aisha VIII-A</p>
        <div className="bg-white/20 rounded-2xl p-3 mt-4 flex justify-between items-center">
          <span className="text-white/80 text-sm">Total Pembayaran</span>
          <span className="text-white font-black text-xl">Rp 750.000</span>
        </div>
      </div>

      <div className="flex-1 px-5 pt-5 pb-8">
        <p className="text-xs text-gray-500 font-semibold mb-3 uppercase tracking-wider">Pilih Cara Bayar</p>
        {methods.map((m) => (
          <button
            key={m.id}
            onClick={() => navigate(m.screen)}
            className="w-full flex items-center gap-4 bg-white border border-gray-100 rounded-2xl p-4 mb-3 shadow-sm active:scale-[0.98] transition-all hover:border-purple-200">
            <div className="w-12 h-12 bg-purple-50 rounded-xl flex items-center justify-center text-2xl flex-none">
              {m.icon}
            </div>
            <div className="flex-1 text-left">
              <div className="flex items-center gap-2">
                <p className="font-bold text-gray-800 text-sm">{m.title}</p>
                <span className="bg-purple-100 text-purple-700 text-[10px] font-semibold px-2 py-0.5 rounded-full">{m.badge}</span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">{m.desc}</p>
            </div>
            <svg className="w-5 h-5 text-gray-300 flex-none" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M9 18l6-6-6-6" strokeLinecap="round"/>
            </svg>
          </button>
        ))}

        <div className="mt-2 bg-gray-50 rounded-2xl p-4">
          <div className="flex items-center gap-2 mb-1">
            <svg className="w-4 h-4 text-green-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M9 12l2 2 4-4M7.835 4.697a3.42 3.42 0 001.946-.806 3.42 3.42 0 014.438 0 3.42 3.42 0 001.946.806 3.42 3.42 0 013.138 3.138 3.42 3.42 0 00.806 1.946 3.42 3.42 0 010 4.438 3.42 3.42 0 00-.806 1.946 3.42 3.42 0 01-3.138 3.138 3.42 3.42 0 00-1.946.806 3.42 3.42 0 01-4.438 0 3.42 3.42 0 00-1.946-.806 3.42 3.42 0 01-3.138-3.138 3.42 3.42 0 00-.806-1.946 3.42 3.42 0 010-4.438 3.42 3.42 0 00.806-1.946 3.42 3.42 0 013.138-3.138z" strokeLinecap="round"/>
            </svg>
            <p className="text-xs font-semibold text-gray-700">Pembayaran Aman & Resmi</p>
          </div>
          <p className="text-xs text-gray-500">Seluruh transaksi tercatat dan dapat diverifikasi. Invoice resmi diterbitkan setelah pembayaran berhasil.</p>
        </div>
      </div>
    </div>
  );
}
