import { Screen } from "../App";

const notifs = [
  {
    type: "warning",
    title: "Pengingat Pembayaran",
    msg: "SPP Agustus 2026 untuk Aisha belum dibayar. Jatuh tempo 10 Agustus 2026.",
    time: "Hari ini, 08:00",
    unread: true,
    action: "rincian-tagihan" as Screen,
    actionLabel: "Bayar Sekarang",
  },
  {
    type: "info",
    title: "Tagihan Semester Tersedia",
    msg: "Tagihan sekolah Semester Ganjil 2026/2027 telah tersedia. Lihat rincian SPP, biaya kegiatan, dan biaya gedung Aisha.",
    time: "1 Agustus 2026",
    unread: true,
    action: "ringkasan-semester" as Screen,
    actionLabel: "Lihat Kewajiban",
  },
  {
    type: "success",
    title: "Pembayaran SPP Juli Berhasil",
    msg: "SPP Juli 2026 sebesar Rp 750.000 telah diterima. Invoice tersedia.",
    time: "7 Juli 2026",
    unread: false,
    action: "invoice" as Screen,
    actionLabel: "Lihat Invoice",
  },
  {
    type: "agenda",
    title: "Agenda: Kunjungan Edukasi",
    msg: "Kunjungan Edukasi Semester Ganjil dijadwalkan 20 Agustus 2026. Biaya Rp 200.000 jatuh tempo 15 Agustus.",
    time: "3 Agustus 2026",
    unread: false,
    action: "kalender" as Screen,
    actionLabel: "Lihat Kalender",
  },
];

const iconMap: Record<string, { bg: string; icon: string }> = {
  warning: { bg: "bg-yellow-100", icon: "⚠️" },
  info: { bg: "bg-purple-100", icon: "📋" },
  success: { bg: "bg-green-100", icon: "✅" },
  agenda: { bg: "bg-blue-100", icon: "📅" },
};

export default function NotifikasiScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-6" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-6 flex items-center justify-between" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <div>
          <button onClick={() => navigate("beranda")} className="text-white/80 mb-2 flex items-center gap-1">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
              <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </button>
          <h2 className="text-white font-bold text-xl">Notifikasi</h2>
          <p className="text-purple-200 text-sm">2 belum dibaca</p>
        </div>
        <button className="text-purple-200 text-xs font-semibold">Tandai Semua</button>
      </div>

      <div className="px-5 pt-4">
        {notifs.map((n, i) => {
          const { bg, icon } = iconMap[n.type];
          return (
            <div key={i} className={`bg-white rounded-2xl p-4 mb-3 shadow-sm ${n.unread ? "border-l-4 border-purple-500" : ""}`}>
              <div className="flex items-start gap-3">
                <div className={`w-10 h-10 ${bg} rounded-xl flex items-center justify-center text-lg flex-none`}>
                  {icon}
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-1">
                    <p className={`text-sm font-bold ${n.unread ? "text-purple-800" : "text-gray-800"}`}>{n.title}</p>
                    {n.unread && <div className="w-2 h-2 bg-purple-500 rounded-full"/>}
                  </div>
                  <p className="text-xs text-gray-600 leading-relaxed mb-2">{n.msg}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-gray-400">{n.time}</span>
                    <button
                      onClick={() => navigate(n.action)}
                      className="text-purple-600 text-xs font-bold">
                      {n.actionLabel} →
                    </button>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
