import { Screen } from "../App";

export default function RincianTagihanScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-6" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("daftar-tagihan")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white/20 rounded-2xl flex items-center justify-center text-2xl">💳</div>
          <div>
            <h2 className="text-white font-bold text-lg">SPP Agustus 2026</h2>
            <span className="bg-yellow-400/90 text-yellow-900 text-xs font-bold px-2.5 py-1 rounded-full">Segera Jatuh Tempo</span>
          </div>
        </div>
      </div>

      <div className="px-5 -mt-3">
        <div className="bg-white rounded-3xl p-4 shadow-sm mb-4">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Informasi Siswa</h3>
          {[
            ["Nama Siswa", "Aisha Nur Fadilah"],
            ["Nomor Induk Siswa", "2024.001.0342"],
            ["Kelas", "VIII-A"],
            ["Tahun Ajaran", "2026/2027"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-2 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500">{k}</span>
              <span className="text-xs font-semibold text-gray-800">{v}</span>
            </div>
          ))}
        </div>

        <div className="bg-white rounded-3xl p-4 shadow-sm mb-4">
          <h3 className="font-bold text-gray-800 text-sm mb-3">Rincian Pembayaran</h3>
          {[
            ["Jenis Tagihan", "SPP Bulanan"],
            ["Periode", "Agustus 2026"],
            ["Tanggal Terbit", "1 Agustus 2026"],
            ["Jatuh Tempo", "10 Agustus 2026"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-2 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500">{k}</span>
              <span className="text-xs font-semibold text-gray-800">{v}</span>
            </div>
          ))}
          <div className="mt-3 pt-3 border-t border-gray-100">
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-500">Nominal Awal</span>
              <span className="text-sm font-semibold text-gray-800">Rp 750.000</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-500">Potongan</span>
              <span className="text-sm font-semibold text-green-600">— Rp 0</span>
            </div>
            <div className="flex justify-between py-1.5">
              <span className="text-sm text-gray-500">Denda</span>
              <span className="text-sm font-semibold text-gray-800">Rp 0</span>
            </div>
            <div className="flex justify-between py-2 mt-1 bg-purple-50 px-3 rounded-xl">
              <span className="text-sm font-bold text-purple-800">Total</span>
              <span className="text-lg font-black text-purple-700">Rp 750.000</span>
            </div>
          </div>
        </div>

        <div className="bg-blue-50 border border-blue-100 rounded-2xl p-3 mb-4 flex gap-2.5">
          <svg className="w-4 h-4 text-blue-600 flex-none mt-0.5" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" strokeLinecap="round"/>
          </svg>
          <p className="text-blue-700 text-xs leading-relaxed">
            Kebijakan: Pembayaran dapat dilakukan secara online atau tunai melalui tata usaha. Biaya ini telah disetujui dalam rapat komite sekolah.
          </p>
        </div>

        <button
          onClick={() => navigate("metode-pembayaran")}
          className="w-full py-4 rounded-2xl text-white font-bold text-sm shadow-lg"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Bayar Sekarang — Rp 750.000
        </button>
      </div>
    </div>
  );
}
