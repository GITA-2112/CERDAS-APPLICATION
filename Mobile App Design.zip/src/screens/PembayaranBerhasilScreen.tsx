import { Screen } from "../App";

export default function PembayaranBerhasilScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full flex flex-col items-center pb-8" style={{ background: "linear-gradient(180deg, #f5f3ff 0%, #fff 50%)" }}>
      <div className="w-full px-5 pt-4 pb-10 flex flex-col items-center"
        style={{ background: "linear-gradient(160deg, #059669, #10b981)" }}>
        <div className="mt-8 relative">
          <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center">
            <div className="w-18 h-18 bg-white rounded-full flex items-center justify-center w-16 h-16">
              <svg className="w-10 h-10 text-green-600" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
        </div>
        <h2 className="text-white font-black text-2xl mt-4">Pembayaran Berhasil!</h2>
        <p className="text-green-100 text-sm mt-1">SPP Agustus 2026 — Aisha VIII-A</p>
      </div>

      <div className="w-full px-5 -mt-6">
        <div className="bg-white rounded-3xl p-5 shadow-lg mb-4">
          <div className="text-center mb-4">
            <p className="text-xs text-gray-400">Total Dibayar</p>
            <p className="text-3xl font-black text-green-600">Rp 750.000</p>
          </div>
          <div className="bg-green-50 rounded-xl px-4 py-2 text-center mb-4">
            <span className="text-green-700 text-xs font-bold">✓ LUNAS</span>
          </div>
          {[
            ["No. Transaksi", "TRX-20260807-4892"],
            ["Tanggal & Waktu", "7 Agustus 2026, 09:42 WIB"],
            ["Metode", "QRIS"],
            ["Nama Siswa", "Aisha Nur Fadilah"],
            ["Periode", "Agustus 2026"],
          ].map(([k, v]) => (
            <div key={k} className="flex justify-between py-2 border-b border-gray-50 last:border-0">
              <span className="text-xs text-gray-500">{k}</span>
              <span className="text-xs font-semibold text-gray-800">{v}</span>
            </div>
          ))}
        </div>

        <div className="flex gap-3 mb-4">
          <button
            onClick={() => navigate("invoice")}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-2xl text-white font-bold text-sm"
            style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" strokeLinecap="round"/>
            </svg>
            Lihat Invoice
          </button>
          <button className="w-12 h-12 bg-gray-100 rounded-2xl flex items-center justify-center">
            <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        <button
          onClick={() => navigate("beranda")}
          className="w-full py-3 rounded-2xl border-2 border-purple-200 text-purple-700 font-semibold text-sm">
          Kembali ke Beranda
        </button>
      </div>
    </div>
  );
}
