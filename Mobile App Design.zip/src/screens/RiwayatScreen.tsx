import { Screen } from "../App";

const history = [
  { name: "SPP Juli 2026", amount: "Rp 750.000", date: "7 Jul 2026", method: "QRIS", status: "Lunas", inv: true },
  { name: "SPP Juni 2026", amount: "Rp 750.000", date: "5 Jun 2026", method: "Virtual Account BCA", status: "Lunas", inv: true },
  { name: "Kemah Pramuka", amount: "Rp 350.000", date: "12 Jun 2026", method: "QRIS", status: "Lunas", inv: true },
  { name: "SPP Mei 2026", amount: "Rp 750.000", date: "9 Mei 2026", method: "Tunai", status: "Lunas", inv: true },
  { name: "SPP April 2026", amount: "Rp 750.000", date: "8 Apr 2026", method: "QRIS", status: "Lunas", inv: true },
];

export default function RiwayatScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-6" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <h2 className="text-white font-bold text-xl mb-1">Riwayat Pembayaran</h2>
        <p className="text-purple-200 text-sm">Aisha Nur Fadilah · VIII-A</p>
        <div className="bg-white/15 rounded-2xl p-3 mt-3 flex justify-between">
          <div>
            <p className="text-white/70 text-xs">Total Dibayar 2026</p>
            <p className="text-white font-black text-lg">Rp 3.600.000</p>
          </div>
          <div>
            <p className="text-white/70 text-xs">Transaksi</p>
            <p className="text-white font-black text-lg">5 kali</p>
          </div>
        </div>
      </div>

      <div className="px-5 pt-4">
        <div className="flex items-center justify-between mb-3">
          <p className="text-xs font-semibold text-gray-500 uppercase tracking-wider">2026</p>
          <button className="bg-white border border-gray-200 rounded-xl px-3 py-1.5 text-xs font-semibold text-gray-600">Filter</button>
        </div>

        {history.map((item, i) => (
          <button
            key={i}
            onClick={() => navigate("invoice")}
            className="w-full flex items-center gap-3 bg-white rounded-2xl p-4 mb-3 shadow-sm active:scale-[0.98] transition-all">
            <div className="w-10 h-10 bg-green-100 rounded-xl flex items-center justify-center flex-none">
              <svg className="w-5 h-5 text-green-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" strokeLinecap="round"/>
              </svg>
            </div>
            <div className="flex-1 text-left">
              <p className="text-sm font-bold text-gray-800">{item.name}</p>
              <p className="text-xs text-gray-500">{item.date} · {item.method}</p>
            </div>
            <div className="text-right">
              <p className="text-sm font-black text-green-600">{item.amount}</p>
              <span className="text-[10px] text-green-600 bg-green-50 px-2 py-0.5 rounded-full font-semibold">{item.status}</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
