import { Screen } from "../App";

export default function TunaiScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full bg-white flex flex-col">
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("metode-pembayaran")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Bayar di Tata Usaha</h2>
        <p className="text-purple-200 text-sm">Pembayaran tunai langsung di sekolah</p>
      </div>

      <div className="flex-1 px-5 pt-5 pb-8">
        {/* Info */}
        <div className="bg-white border border-gray-100 rounded-2xl p-4 shadow-sm mb-4">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-purple-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M19 21V5a2 2 0 00-2-2H7a2 2 0 00-2 2v16m14 0h2m-2 0h-5m-9 0H3m2 0h5M9 7h1m-1 4h1m4-4h1m-1 4h1m-5 10v-5a1 1 0 011-1h2a1 1 0 011 1v5m-4 0h4" strokeLinecap="round"/>
              </svg>
            </div>
            <div>
              <p className="font-bold text-gray-800 text-sm">Tata Usaha SMP Negeri 5</p>
              <p className="text-xs text-gray-500">Gedung Utama Lt. 1</p>
            </div>
          </div>
          <div className="bg-gray-50 rounded-xl p-3">
            <p className="text-xs font-semibold text-gray-700 mb-2">Jam Operasional</p>
            {[
              { day: "Senin – Kamis", time: "07.30 – 14.30 WIB" },
              { day: "Jumat", time: "07.30 – 11.30 WIB" },
              { day: "Sabtu – Minggu", time: "Tutup" },
            ].map(({ day, time }) => (
              <div key={day} className="flex justify-between py-1">
                <span className="text-xs text-gray-500">{day}</span>
                <span className="text-xs font-medium text-gray-700">{time}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-purple-50 border border-purple-200 rounded-2xl p-4 mb-4">
          <p className="text-sm font-bold text-purple-800 mb-1">Yang perlu dibawa:</p>
          {[
            "Kode pembayaran di bawah",
            "Uang tunai: Rp 750.000",
            "Kartu identitas orang tua",
          ].map((item) => (
            <div key={item} className="flex items-center gap-2 py-1">
              <div className="w-1.5 h-1.5 rounded-full bg-purple-500"/>
              <span className="text-xs text-purple-700">{item}</span>
            </div>
          ))}
        </div>

        {/* Payment code */}
        <div className="bg-white border-2 border-dashed border-gray-200 rounded-2xl p-4 mb-4 text-center">
          <p className="text-xs text-gray-400 mb-1">Kode Pembayaran</p>
          <p className="font-black text-2xl text-gray-800 tracking-[6px]">CRD-4892</p>
          <p className="text-xs text-gray-400 mt-1">Tunjukkan kode ini ke petugas TU</p>
        </div>

        <button
          onClick={() => navigate("jadwalkan-pertemuan")}
          className="w-full py-3 rounded-2xl border-2 border-purple-200 text-purple-700 font-semibold text-sm mb-3">
          Buat Jadwal Kunjungan
        </button>

        <button
          onClick={() => navigate("pembayaran-berhasil")}
          className="w-full py-3.5 rounded-2xl text-white font-bold text-sm"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Simulasi: Pembayaran Diterima
        </button>
      </div>
    </div>
  );
}
