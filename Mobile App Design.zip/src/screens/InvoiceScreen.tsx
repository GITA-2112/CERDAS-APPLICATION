import { Screen } from "../App";

export default function InvoiceScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-8" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-4" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("pembayaran-berhasil")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Invoice Resmi</h2>
        <p className="text-purple-200 text-sm">Bukti Pembayaran SPP</p>
      </div>

      <div className="px-5 pt-4">
        <div className="bg-white rounded-3xl shadow-lg overflow-hidden mb-4">
          {/* Invoice header */}
          <div className="p-5 border-b border-gray-100" style={{ background: "linear-gradient(135deg, #6d28d9, #4f46e5)" }}>
            <div className="flex items-center gap-3 mb-3">
              <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center">
                <span className="text-xl font-black text-purple-700">C</span>
              </div>
              <div>
                <p className="text-white font-bold text-sm">CERDAS</p>
                <p className="text-purple-200 text-xs">SMP Negeri 5 Jakarta</p>
              </div>
            </div>
            <div className="flex justify-between items-end">
              <div>
                <p className="text-purple-200 text-xs">No. Invoice</p>
                <p className="text-white font-bold text-sm">INV-2026-08-4892</p>
              </div>
              <div className="bg-green-400/90 text-green-900 text-xs font-black px-3 py-1.5 rounded-xl">
                ✓ LUNAS
              </div>
            </div>
          </div>

          <div className="p-5">
            {[
              ["Nama Siswa", "Aisha Nur Fadilah"],
              ["Nomor Induk Siswa", "2024.001.0342"],
              ["Kelas", "VIII-A"],
              ["Jenis Pembayaran", "SPP Bulanan"],
              ["Periode", "Agustus 2026"],
              ["Nominal", "Rp 750.000"],
              ["Potongan", "—"],
              ["Total Dibayar", "Rp 750.000"],
              ["Metode", "QRIS"],
              ["Tanggal Transaksi", "7 Agustus 2026, 09:42"],
              ["Nama Orang Tua", "Maya Sari Dewi"],
            ].map(([k, v]) => (
              <div key={k} className="flex justify-between py-2 border-b border-gray-50 last:border-0">
                <span className="text-xs text-gray-500">{k}</span>
                <span className={`text-xs font-semibold ${k === "Total Dibayar" ? "text-purple-700 font-black" : "text-gray-800"}`}>{v}</span>
              </div>
            ))}

            {/* Crypto hash */}
            <div className="mt-3 bg-gray-50 rounded-xl p-3">
              <p className="text-[9px] text-gray-400 font-mono mb-0.5">Kode Verifikasi Dokumen</p>
              <p className="text-[9px] text-gray-500 font-mono break-all">SHA256: a3f9b2e1c4d5f8a9b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5e6f7a8b9c0d1e2f3</p>
            </div>

            {/* QR verification */}
            <div className="flex items-center gap-3 mt-3 p-3 border border-gray-100 rounded-xl">
              <div className="w-14 h-14 bg-gray-100 rounded-lg flex items-center justify-center flex-none">
                <svg className="w-10 h-10 text-gray-600" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M3 3h7v7H3V3zm2 2v3h3V5H5zm9-2h7v7h-7V3zm2 2v3h3V5h-3zm-11 9H3v7h7v-7H5zm0 2h3v3H5v-3zm11-2v2h-2v2h2v2h2v-2h2v-2h-2v-2h-2zm2 6v-2h2v2h-2z"/>
                </svg>
              </div>
              <div>
                <p className="text-xs font-semibold text-gray-700">Verifikasi Keaslian</p>
                <p className="text-[10px] text-gray-500">Scan QR untuk memverifikasi invoice ini</p>
              </div>
            </div>

            <p className="text-[9px] text-gray-400 text-center mt-3">
              Dokumen ini diterbitkan secara digital oleh SMP Negeri 5 Jakarta melalui sistem CERDAS. Keaslian dapat diverifikasi melalui portal cerdas.sch.id/verify
            </p>
          </div>
        </div>

        <div className="flex gap-3">
          <button className="flex-1 py-3 rounded-2xl border-2 border-purple-200 text-purple-700 font-semibold text-sm flex items-center justify-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" strokeLinecap="round"/>
            </svg>
            Unduh PDF
          </button>
          <button className="flex-1 py-3 rounded-2xl bg-green-100 text-green-700 font-semibold text-sm flex items-center justify-center gap-1">
            <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316" strokeLinecap="round"/>
            </svg>
            Bagikan
          </button>
        </div>
      </div>
    </div>
  );
}
