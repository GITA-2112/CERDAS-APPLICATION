import { Screen } from "../App";

export default function ProfilScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-8" style={{ background: "#f5f3ff" }}>
      <div className="px-5 pt-4 pb-12 flex flex-col items-center"
        style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <div className="w-20 h-20 rounded-2xl overflow-hidden bg-white/20 mb-3">
          <img
            src="https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=100&h=100&fit=crop&auto=format"
            alt="Maya"
            className="w-full h-full object-cover"
          />
        </div>
        <h2 className="text-white font-bold text-lg">Maya Sari Dewi</h2>
        <p className="text-purple-200 text-sm">Orang Tua / Wali</p>
        <p className="text-purple-300 text-xs mt-1">+62 812-3456-7890</p>
      </div>

      <div className="px-5 -mt-6">
        {/* Child card */}
        <div className="bg-white rounded-3xl p-4 shadow-lg mb-4">
          <p className="text-xs text-gray-400 font-semibold mb-3 uppercase tracking-wider">Data Anak</p>
          <button onClick={() => navigate("pilih-anak")} className="w-full flex items-center gap-3 active:scale-[0.98] transition-all">
            <div className="w-12 h-12 rounded-xl overflow-hidden flex-none">
              <img src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=80&h=80&fit=crop&auto=format" alt="Aisha" className="w-full h-full object-cover"/>
            </div>
            <div className="flex-1 text-left">
              <p className="font-bold text-gray-800 text-sm">Aisha Nur Fadilah</p>
              <p className="text-xs text-gray-500">NIS: 2024.001.0342 · VIII-A</p>
              <div className="flex gap-1.5 mt-1">
                <span className="bg-green-100 text-green-700 text-[9px] font-bold px-2 py-0.5 rounded-full">Aktif</span>
                <span className="bg-purple-100 text-purple-700 text-[9px] font-bold px-2 py-0.5 rounded-full">TA 2026/2027</span>
              </div>
            </div>
            <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M9 18l6-6-6-6" strokeLinecap="round"/>
            </svg>
          </button>
        </div>

        {/* Menu */}
        <div className="bg-white rounded-3xl p-4 shadow-sm mb-4">
          {[
            { icon: "👤", label: "Data Profil Saya", action: () => {} },
            { icon: "🔔", label: "Pengaturan Notifikasi", action: () => {} },
            { icon: "📋", label: "Ringkasan Semester", action: () => navigate("ringkasan-semester") },
            { icon: "📅", label: "Kalender Pembayaran", action: () => navigate("kalender") },
            { icon: "❓", label: "Pusat Bantuan", action: () => navigate("pusat-bantuan") },
          ].map(({ icon, label, action }) => (
            <button key={label} onClick={action} className="w-full flex items-center gap-3 py-3.5 border-b border-gray-50 last:border-0 active:bg-gray-50 rounded-xl px-1 -mx-1 transition-all">
              <div className="w-9 h-9 bg-purple-50 rounded-xl flex items-center justify-center text-lg">{icon}</div>
              <span className="flex-1 text-sm font-medium text-gray-700 text-left">{label}</span>
              <svg className="w-4 h-4 text-gray-300" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M9 18l6-6-6-6" strokeLinecap="round"/>
              </svg>
            </button>
          ))}
        </div>

        <div className="bg-white rounded-3xl p-4 shadow-sm">
          <button 
            onClick={() => navigate("landing")}
            className="w-full flex items-center gap-3 py-2 active:opacity-70 transition-opacity"
          >
            <div className="w-9 h-9 bg-red-50 rounded-xl flex items-center justify-center text-lg">🚪</div>
            <span className="text-sm font-medium text-red-500">Keluar dari Akun</span>
          </button>
        </div>

        <p className="text-center text-xs text-gray-400 mt-4">CERDAS v1.0.0 · SMP Negeri 5 Jakarta</p>
      </div>
    </div>
  );
}
