import { useState, useEffect } from "react";
import { Screen } from "../App";

export default function QRISScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [seconds, setSeconds] = useState(299);

  useEffect(() => {
    const t = setInterval(() => setSeconds(s => s > 0 ? s - 1 : 0), 1000);
    return () => clearInterval(t);
  }, []);

  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;

  return (
    <div className="min-h-full bg-white flex flex-col">
      <div className="px-5 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("metode-pembayaran")} className="text-white/80 mb-4 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h2 className="text-white font-bold text-xl">Pembayaran QRIS</h2>
        <p className="text-purple-200 text-sm">Scan QR dengan dompet digital Anda</p>
      </div>

      <div className="flex-1 px-5 pt-5 pb-8 flex flex-col items-center">
        <div className="bg-purple-50 border-2 border-dashed border-purple-300 rounded-3xl p-5 w-full flex flex-col items-center mb-5">
          {/* QR Pattern */}
          <div className="w-48 h-48 bg-white rounded-2xl p-3 mb-3 shadow-sm">
            <div className="w-full h-full rounded-xl overflow-hidden grid grid-cols-10 gap-0.5 p-1">
              {Array.from({ length: 100 }, (_, i) => {
                const corners = [0,1,2,10,11,12,20,21,22,7,8,9,17,18,19,27,28,29,70,71,72,80,81,82,90,91,92,77,78,79,87,88,89,97,98,99];
                const dots = [33,34,44,45,55,56,66,43,53,54,64,35,46,65,36,47,57,58,67];
                const isCorner = corners.includes(i);
                const isDot = dots.includes(i);
                return (
                  <div key={i} className={`rounded-sm ${isCorner ? "bg-purple-700" : isDot ? "bg-purple-500" : Math.random() > 0.6 ? "bg-gray-200" : "bg-white"}`}/>
                );
              })}
            </div>
          </div>
          <div className="flex items-center gap-2 text-purple-700">
            <svg className="w-5 h-5" viewBox="0 0 24 24" fill="currentColor">
              <path d="M3 3h7v7H3V3zm2 2v3h3V5H5zm9-2h7v7h-7V3zm2 2v3h3V5h-3zm-11 9H3v7h7v-7H5zm0 2h3v3H5v-3zm11-2v2h-2v2h2v2h2v-2h2v-2h-2v-2h-2zm2 6v-2h2v2h-2z"/>
            </svg>
            <span className="font-bold text-sm">QRIS — CERDAS Sekolah</span>
          </div>
        </div>

        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-3 w-full mb-5 flex items-center justify-between">
          <div>
            <p className="text-xs text-yellow-700 font-semibold">QR berlaku</p>
            <p className="text-yellow-800 font-black text-2xl">{mins}:{String(secs).padStart(2,"0")}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-yellow-700">Total Pembayaran</p>
            <p className="font-black text-xl text-yellow-800">Rp 750.000</p>
          </div>
        </div>

        <div className="w-full bg-gray-50 rounded-2xl p-4 mb-5">
          <p className="text-xs font-semibold text-gray-700 mb-2">Cara Bayar:</p>
          {["Buka aplikasi dompet digital (GoPay, OVO, Dana, dll)", "Pilih menu \"Bayar\" atau \"Scan QR\"", "Arahkan kamera ke kode QR di atas", "Konfirmasi pembayaran"].map((step, i) => (
            <div key={i} className="flex items-start gap-2.5 mb-2 last:mb-0">
              <div className="w-5 h-5 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center text-xs font-bold flex-none">{i+1}</div>
              <p className="text-xs text-gray-600">{step}</p>
            </div>
          ))}
        </div>

        <button
          onClick={() => navigate("pembayaran-berhasil")}
          className="w-full py-3.5 rounded-2xl text-white font-bold text-sm"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Simulasi: Konfirmasi Pembayaran
        </button>
      </div>
    </div>
  );
}
