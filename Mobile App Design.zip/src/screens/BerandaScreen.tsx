import { Screen } from "../App";

export default function BerandaScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full pb-4" style={{ background: "#f5f3ff" }}>
      {/* Header */}
      <div className="relative px-5 pt-4 pb-16 rounded-b-[36px] overflow-hidden"
        style={{ background: "linear-gradient(160deg, #6d28d9 0%, #7c3aed 60%, #8b5cf6 100%)" }}>
        <div className="flex items-center justify-between mb-4">
          <button onClick={() => navigate("pilih-anak")} className="flex items-center gap-2">
            <div className="w-9 h-9 rounded-xl overflow-hidden bg-white/20">
              <img src="https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=80&h=80&fit=crop&auto=format" alt="Aisha" className="w-full h-full object-cover"/>
            </div>
            <div>
              <p className="text-white/70 text-xs">Halo, Ibu Maya</p>
              <div className="flex items-center gap-1">
                <p className="text-white text-sm font-bold">Aisha — VIII-A</p>
                <svg className="w-3.5 h-3.5 text-white/70" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                  <path d="M19 9l-7 7-7-7" strokeLinecap="round"/>
                </svg>
              </div>
            </div>
          </button>
          <button onClick={() => navigate("notifikasi")} className="relative w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
            <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M15 17H20L18.595 15.595A2 2 0 0118 14.172V11A6 6 0 006 11v3.172A2 2 0 015.405 15.595L4 17H9M15 17V18A3 3 0 019 18V17M15 17H9" strokeLinecap="round"/>
            </svg>
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full"/>
          </button>
        </div>

        {/* Summary card */}
        <div className="bg-white/15 backdrop-blur rounded-2xl p-4">
          <p className="text-white/70 text-xs mb-3">Kewajiban Agustus 2026</p>
          <div className="flex items-end justify-between mb-3">
            <div>
              <p className="text-white/70 text-xs">Total Bulan Ini</p>
              <p className="text-white font-bold text-2xl">Rp 750.000</p>
            </div>
            <span className="bg-yellow-400/90 text-yellow-900 text-xs font-bold px-3 py-1.5 rounded-full">
              Segera Jatuh Tempo
            </span>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => navigate("rincian-tagihan")}
              className="flex-1 py-2.5 bg-white rounded-xl text-purple-700 text-xs font-bold active:scale-95 transition-all">
              Bayar Sekarang
            </button>
            <button
              onClick={() => navigate("daftar-tagihan")}
              className="flex-1 py-2.5 bg-white/20 rounded-xl text-white text-xs font-semibold active:scale-95 transition-all">
              Lihat Semua
            </button>
          </div>
        </div>
      </div>

      {/* Cards */}
      <div className="px-5 -mt-8">
        {/* Stats row */}
        <div className="grid grid-cols-3 gap-3 mb-4">
          {[
            { label: "Sudah Dibayar", val: "Rp 3,6 jt", color: "text-green-600", bg: "bg-green-50", border: "border-green-100" },
            { label: "Belum Dibayar", val: "Rp 750 rb", color: "text-orange-600", bg: "bg-orange-50", border: "border-orange-100" },
            { label: "Tagihan Aktif", val: "3", color: "text-purple-600", bg: "bg-purple-50", border: "border-purple-100" },
          ].map(({ label, val, color, bg, border }) => (
            <div key={label} className={`${bg} border ${border} rounded-2xl p-3 text-center`}>
              <p className={`font-bold text-sm ${color}`}>{val}</p>
              <p className="text-gray-500 text-[10px] mt-0.5 leading-tight">{label}</p>
            </div>
          ))}
        </div>

        {/* Upcoming bills */}
        <div className="bg-white rounded-3xl p-4 mb-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm">Tagihan Mendatang</h3>
            <button onClick={() => navigate("daftar-tagihan")} className="text-purple-600 text-xs font-semibold">Lihat Semua</button>
          </div>
          {[
            { name: "SPP Agustus 2026", amount: "Rp 750.000", due: "10 Agt 2026", status: "Segera Jatuh Tempo", statusClass: "status-jatuh-tempo" },
            { name: "Kunjungan Edukasi", amount: "Rp 200.000", due: "20 Agt 2026", status: "Mendatang", statusClass: "status-mendatang" },
            { name: "Biaya Gedung Sem.1", amount: "Rp 500.000", due: "30 Agt 2026", status: "Mendatang", statusClass: "status-mendatang" },
          ].map((bill) => (
            <button
              key={bill.name}
              onClick={() => navigate("rincian-tagihan")}
              className="w-full flex items-center justify-between py-3 border-b border-gray-50 last:border-0 active:bg-gray-50 rounded-xl px-1 -mx-1 transition-all">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 bg-purple-100 rounded-xl flex items-center justify-center">
                  <svg className="w-4 h-4 text-purple-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <rect x="4" y="2" width="16" height="20" rx="2"/>
                    <path d="M8 7h8M8 11h6" strokeLinecap="round"/>
                  </svg>
                </div>
                <div className="text-left">
                  <p className="text-sm font-semibold text-gray-800">{bill.name}</p>
                  <p className="text-xs text-gray-500">Jatuh tempo {bill.due}</p>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm font-bold text-gray-800">{bill.amount}</p>
                <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${bill.statusClass}`}>{bill.status}</span>
              </div>
            </button>
          ))}
        </div>

        {/* School agenda */}
        <div className="bg-white rounded-3xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-bold text-gray-800 text-sm">Agenda Sekolah</h3>
            <button onClick={() => navigate("kalender")} className="text-purple-600 text-xs font-semibold">Kalender</button>
          </div>
          {[
            { name: "Kunjungan Edukasi Sem. Ganjil", date: "20 Agustus 2026", note: "Disepakati Komite Sekolah 15 Jul 2026" },
            { name: "Ujian Tengah Semester", date: "15 September 2026", note: "Tidak ada biaya tambahan" },
          ].map((agenda) => (
            <div key={agenda.name} className="flex gap-3 py-2.5 border-b border-gray-50 last:border-0">
              <div className="w-9 h-9 bg-blue-100 rounded-xl flex items-center justify-center flex-none">
                <svg className="w-4 h-4 text-blue-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                  <rect x="3" y="4" width="18" height="18" rx="2"/>
                  <path d="M16 2v4M8 2v4M3 10h18" strokeLinecap="round"/>
                </svg>
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-800">{agenda.name}</p>
                <p className="text-xs text-blue-600 font-medium">{agenda.date}</p>
                <p className="text-xs text-gray-400 mt-0.5">{agenda.note}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Alert banner */}
        <div className="bg-yellow-50 border border-yellow-200 rounded-2xl p-4 mt-4 flex gap-3">
          <div className="w-8 h-8 bg-yellow-100 rounded-xl flex items-center justify-center flex-none">
            <svg className="w-4 h-4 text-yellow-700" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M12 9v4M12 17h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z" strokeLinecap="round"/>
            </svg>
          </div>
          <div className="flex-1">
            <p className="text-yellow-800 text-xs font-semibold">SPP Agustus jatuh tempo 3 hari lagi</p>
            <p className="text-yellow-700 text-xs mt-0.5">Pastikan pembayaran sebelum 10 Agustus 2026 untuk menghindari keterlambatan.</p>
            <button onClick={() => navigate("metode-pembayaran")} className="text-yellow-700 font-bold text-xs mt-2 underline">Bayar Sekarang</button>
          </div>
        </div>
      </div>
    </div>
  );
}
