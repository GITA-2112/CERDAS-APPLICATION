import { useEffect } from "react";
import { Screen } from "../App";

export default function SplashScreen({ navigate }: { navigate: (s: Screen) => void }) {
  useEffect(() => {
    const t = setTimeout(() => navigate("landing"), 2500);
    return () => clearTimeout(t);
  }, [navigate]);

  return (
    <div className="h-full flex flex-col items-center justify-center"
      style={{ background: "linear-gradient(160deg, #6d28d9 0%, #7c3aed 40%, #4f46e5 100%)" }}>
      {/* Logo */}
      <div className="flex flex-col items-center gap-4">
        <div className="w-24 h-24 bg-white/20 backdrop-blur rounded-3xl flex items-center justify-center shadow-2xl">
          <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center">
            <svg className="w-10 h-10 text-purple-700" fill="none" viewBox="0 0 40 40">
              <rect x="4" y="4" width="32" height="32" rx="8" fill="#7c3aed" opacity="0.15"/>
              <path d="M20 8C13.4 8 8 13.4 8 20s5.4 12 12 12 12-5.4 12-12S26.6 8 20 8z" fill="#7c3aed" opacity="0.3"/>
              <path d="M15 20h10M15 15h6M15 25h8" stroke="#6d28d9" strokeWidth="2.5" strokeLinecap="round"/>
              <circle cx="27" cy="14" r="3" fill="#22c55e"/>
            </svg>
          </div>
        </div>
        <div className="text-center">
          <h1 className="text-4xl font-bold text-white tracking-tight">CERDAS</h1>
          <p className="text-purple-200 text-sm mt-1 font-medium">Catatan Elektronik, Reminder &</p>
          <p className="text-purple-200 text-sm font-medium">Administrasi Sekolah</p>
        </div>
      </div>

      {/* Bottom */}
      <div className="absolute bottom-16 flex flex-col items-center gap-3">
        <div className="flex gap-1.5">
          <div className="w-6 h-1.5 bg-white rounded-full"/>
          <div className="w-1.5 h-1.5 bg-white/40 rounded-full"/>
          <div className="w-1.5 h-1.5 bg-white/40 rounded-full"/>
        </div>
        <p className="text-white/60 text-xs">Sistem Administrasi Keuangan Sekolah</p>
      </div>
    </div>
  );
}
