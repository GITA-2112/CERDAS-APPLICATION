import { Screen } from "../App";
import heroImage from "../imports/ChatGPT_Image_Sep_5__2026__09_51_32_AM.png";

export default function LandingScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="h-full bg-white flex flex-col">
      {/* Hero Image Section */}
      <div className="flex-none h-[55%] w-full relative bg-purple-50">
        <div className="absolute inset-0 bg-gradient-to-b from-transparent to-white/90 z-10" />
        <img 
          src={heroImage} 
          alt="CERDAS App Illustration" 
          className="w-full h-full object-cover"
        />
      </div>

      {/* Content Section */}
      <div className="flex-1 flex flex-col px-6 pt-4 pb-12 z-20 -mt-12 bg-white rounded-t-3xl relative">
        <div className="flex-1 flex flex-col items-center text-center">
          <div className="w-16 h-16 bg-purple-600 rounded-2xl flex items-center justify-center shadow-lg shadow-purple-200 mb-6 mt-4">
            <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path d="M12 14l9-5-9-5-9 5 9 5z" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M12 14l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14z" strokeLinecap="round" strokeLinejoin="round" />
              <path d="M12 14l9-5-9-5-9 5 9 5zm0 0l6.16-3.422a12.083 12.083 0 01.665 6.479A11.952 11.952 0 0012 20.055a11.952 11.952 0 00-6.824-2.998 12.078 12.078 0 01.665-6.479L12 14zm-4 6v-7.5l4-2.222" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <h1 className="text-3xl font-bold text-gray-900 mb-3 tracking-tight">CERDAS</h1>
          <p className="text-gray-500 text-sm leading-relaxed max-w-[300px]">
            Sistem Catatan Elektronik, Reminder & Administrasi Sekolah terpadu untuk kemudahan pendidikan anak.
          </p>
        </div>
        
        {/* Actions */}
        <div className="flex flex-col gap-3 mt-auto">
          <button
            onClick={() => navigate("aktivasi")}
            className="w-full bg-purple-600 active:bg-purple-700 text-white rounded-2xl py-4 font-bold text-sm shadow-lg shadow-purple-200/50 transition-colors"
          >
            Masuk ke Akun
          </button>
          <button
            onClick={() => navigate("aktivasi")}
            className="w-full bg-purple-50 active:bg-purple-100 text-purple-700 border border-purple-100 rounded-2xl py-4 font-bold text-sm transition-colors"
          >
            Daftar Akun Baru
          </button>
        </div>
      </div>
    </div>
  );
}
