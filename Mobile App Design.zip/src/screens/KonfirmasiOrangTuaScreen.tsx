import { Screen } from "../App";

export default function KonfirmasiOrangTuaScreen({ navigate }: { navigate: (s: Screen) => void }) {
  return (
    <div className="min-h-full bg-white flex flex-col">
      <div className="px-6 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("otp")} className="text-white/80 mb-6 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="text-sm">Kembali</span>
        </button>
        <h2 className="text-white font-bold text-xl">Konfirmasi Data Anda</h2>
        <p className="text-purple-200 text-sm mt-1">Periksa dan lengkapi data diri Anda</p>
      </div>

      <div className="flex-1 px-6 pt-6 pb-8">
        <div className="flex items-center gap-4 mb-6">
          <div className="w-16 h-16 rounded-2xl bg-purple-100 flex items-center justify-center text-2xl font-bold text-purple-700">
            MY
          </div>
          <div>
            <p className="font-bold text-gray-800 text-lg">Ibu Maya Sari</p>
            <p className="text-gray-500 text-sm">Orang Tua / Wali</p>
          </div>
        </div>

        {[
          { label: "Nama Lengkap", value: "Maya Sari Dewi" },
          { label: "Nomor WhatsApp", value: "+62 812-3456-7890" },
          { label: "Alamat Surel", value: "maya.sari@gmail.com" },
          { label: "Alamat", value: "Jl. Melati No. 12, Jakarta Selatan" },
          { label: "Kanal Notifikasi", value: "WhatsApp & Aplikasi" },
        ].map(({ label, value }) => (
          <div key={label} className="mb-4">
            <label className="text-xs text-gray-500 font-medium block mb-1">{label}</label>
            <div className="bg-gray-50 border border-gray-200 rounded-xl px-4 py-3 flex items-center justify-between">
              <span className="text-sm font-medium text-gray-800">{value}</span>
              <svg className="w-4 h-4 text-purple-500" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 013.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z" strokeLinecap="round"/>
              </svg>
            </div>
          </div>
        ))}

        <button
          onClick={() => navigate("konfirmasi-anak")}
          className="w-full py-3.5 rounded-2xl text-white font-semibold text-sm mt-4"
          style={{ background: "linear-gradient(135deg, #7c3aed, #6d28d9)" }}>
          Data Sudah Benar, Lanjutkan
        </button>
      </div>
    </div>
  );
}
