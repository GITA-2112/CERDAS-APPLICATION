import { useState } from "react";
import { Screen } from "../App";

export default function OTPScreen({ navigate }: { navigate: (s: Screen) => void }) {
  const [otp, setOtp] = useState(["", "", "", "", "", ""]);

  const handleChange = (i: number, val: string) => {
    if (!/^\d?$/.test(val)) return;
    const next = [...otp];
    next[i] = val;
    setOtp(next);
  };

  const filled = otp.every((d) => d !== "");

  return (
    <div className="min-h-full flex flex-col bg-white">
      {/* Header */}
      <div className="px-6 pt-4 pb-6" style={{ background: "linear-gradient(160deg, #6d28d9, #8b5cf6)" }}>
        <button onClick={() => navigate("aktivasi")} className="text-white/80 mb-6 flex items-center gap-1">
          <svg className="w-5 h-5" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
            <path d="M19 12H5M12 5l-7 7 7 7" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="text-sm">Kembali</span>
        </button>
        <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mb-4">
          <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
            <path d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" strokeLinecap="round"/>
          </svg>
        </div>
        <h2 className="text-white font-bold text-xl">Verifikasi Nomor</h2>
        <p className="text-purple-200 text-sm mt-1">
          Masukkan 6-digit kode OTP yang dikirim ke <span className="text-white font-medium">+62 812-3456-7890</span>
        </p>
      </div>

      <div className="flex-1 px-6 pt-8">
        {/* OTP Boxes */}
        <div className="flex gap-2 justify-center mb-8">
          {otp.map((digit, i) => (
            <div
              key={i}
              className={`w-12 h-14 rounded-xl border-2 flex items-center justify-center text-xl font-bold transition-all
                ${digit ? "border-purple-500 bg-purple-50 text-purple-700" : "border-gray-200 bg-gray-50 text-gray-300"}`}
            >
              {digit || "—"}
            </div>
          ))}
        </div>

        {/* Simulated input */}
        <div className="bg-gray-50 rounded-2xl p-4 mb-6">
          <p className="text-xs text-gray-500 mb-3 text-center">Demo: Tap angka untuk mengisi OTP</p>
          <div className="grid grid-cols-3 gap-2">
            {[1,2,3,4,5,6,7,8,9,"",0,"⌫"].map((n, idx) => (
              <button
                key={idx}
                onClick={() => {
                  if (n === "⌫") {
                    const last = [...otp].reverse().findIndex(d => d !== "");
                    if (last >= 0) {
                      const next = [...otp];
                      next[5 - last] = "";
                      setOtp(next);
                    }
                  } else if (n !== "") {
                    const empty = otp.findIndex(d => d === "");
                    if (empty >= 0) handleChange(empty, String(n));
                  }
                }}
                className={`h-12 rounded-xl text-base font-semibold transition-all active:scale-95
                  ${n === "" ? "invisible" : "bg-white border border-gray-200 text-gray-700 hover:bg-purple-50"}`}
              >
                {n}
              </button>
            ))}
          </div>
        </div>

        <button
          disabled={!filled}
          onClick={() => navigate("konfirmasi-ortu")}
          className={`w-full py-3.5 rounded-2xl font-semibold text-sm transition-all active:scale-[0.98]
            ${filled
              ? "text-white"
              : "bg-gray-100 text-gray-400 cursor-not-allowed"}`}
          style={filled ? { background: "linear-gradient(135deg, #7c3aed, #6d28d9)" } : {}}
        >
          Verifikasi
        </button>

        <div className="mt-4 text-center">
          <p className="text-gray-400 text-xs">
            Tidak menerima kode?{" "}
            <span className="text-purple-600 font-semibold">Kirim Ulang (2:34)</span>
          </p>
        </div>
      </div>
    </div>
  );
}
