Buatkan desain high-fidelity prototype aplikasi seluler bernama “CERDAS — Catatan Elektronik, Reminder & Administrasi Sekolah” yang berfungsi sebagai sistem pembayaran dan peringatan dini kewajiban sekolah.

Gunakan seluruh teks antarmuka dalam Bahasa Indonesia. Buat tampilan modern, sederhana, ramah, tepercaya, dan mudah digunakan oleh orang tua dengan tingkat literasi digital yang beragam.

TUJUAN PRODUK

CERDAS membantu orang tua/wali:

1. Mengetahui seluruh kewajiban pembayaran anak.
2. Menerima notifikasi pembayaran secara personal.
3. Membayar SPP, biaya kegiatan, dan biaya gedung.
4. Melihat kalender pembayaran dan agenda sekolah berbayar.
5. Mendapatkan bukti pembayaran resmi.
6. Menindaklanjuti tunggakan sebelum mencapai status kritis.
7. Menjadwalkan pertemuan dengan tata usaha jika membutuhkan bantuan.

CERDAS membantu sekolah:

1. Mendaftarkan siswa dan orang tua/wali.
2. Mengelola jenis dan jadwal tagihan.
3. Memantau status pembayaran.
4. Mengirim pengingat secara otomatis.
5. Mengidentifikasi tunggakan selama tiga bulan.
6. Mengelola pembayaran tunai.
7. Menjadwalkan konsultasi dengan orang tua.
8. Menyediakan laporan dan jejak audit pembayaran.

TARGET PENGGUNA

1. Orang tua/wali murid.
2. Kepala sekolah.
3. Tata usaha atau administrasi keuangan.
4. Komite sekolah sebagai pihak yang menyepakati agenda dan biaya tertentu.

GAYA VISUAL

Gunakan referensi visual aplikasi keuangan modern dengan ketentuan:

* Warna utama ungu atau biru keunguan.
* Warna latar putih dengan gradasi ungu muda.
* Kartu informasi menggunakan sudut membulat.
* Bayangan lembut dan tampilan bersih.
* Tipografi modern seperti Inter atau Poppins.
* Ikon sederhana dan konsisten.
* Hijau untuk status “Lunas”.
* Kuning untuk status “Segera Jatuh Tempo”.
* Oranye untuk status “Perlu Perhatian”.
* Merah untuk status “Tunggakan Kritis”.
* Jangan membuat tampilan seperti aplikasi pinjaman.
* Jangan menggunakan ilustrasi yang menimbulkan stigma terhadap siswa penerima bantuan.
* Gunakan bahasa yang suportif dan tidak mengintimidasi.

STRUKTUR DATA DAN REGISTRASI

Proses dimulai setelah siswa resmi diterima di sekolah dan memperoleh Nomor Induk Siswa.

Tata usaha mendaftarkan:

* Nomor Induk Siswa.
* Nama siswa.
* Nama orang tua atau wali.
* Nomor telepon dan WhatsApp.
* Alamat surel.
* Alamat tempat tinggal.
* Kelas siswa saat ini.
* Tahun ajaran.
* Status siswa aktif atau tidak aktif.
* Kategori pembiayaan: umum, penerima beasiswa, atau penerima bantuan.
* Jenis program bantuan.
* Persentase atau nominal bantuan.
* Kewajiban pembayaran yang berlaku.
* Preferensi kanal notifikasi.

Informasi kategori pembiayaan harus diperlakukan sebagai data sensitif. Informasi tersebut hanya dapat dilihat oleh orang tua terkait serta petugas sekolah yang memiliki wewenang. Jangan menampilkan status bantuan pada area publik, peringkat, atau daftar siswa umum.

ALUR PROSES UTAMA

Buatkan diagram alur proses dari awal hingga akhir menggunakan tahapan berikut:

1. Siswa diterima di sekolah.
2. Sekolah menerbitkan Nomor Induk Siswa.
3. Tata usaha mendaftarkan data siswa dan orang tua/wali.
4. Sistem membuat akun CERDAS.
5. Orang tua menerima tautan aktivasi melalui WhatsApp.
6. Orang tua melakukan verifikasi nomor telepon menggunakan OTP.
7. Orang tua melengkapi atau mengonfirmasi data profil.
8. Sistem menampilkan profil anak dan kategori pembiayaan yang berlaku.
9. Sekolah menetapkan struktur tagihan berdasarkan tahun ajaran.
10. Sistem menerbitkan tagihan awal semester.
11. Orang tua menerima notifikasi melalui WhatsApp dan aplikasi.
12. Orang tua membuka ringkasan kewajiban.
13. Orang tua memilih jenis tagihan.
14. Orang tua melihat rincian tagihan dan jatuh tempo.
15. Orang tua memilih metode pembayaran.
16. Sistem memproses atau mencatat pembayaran.
17. Sekolah melakukan verifikasi jika diperlukan.
18. Sistem memperbarui status menjadi “Lunas”.
19. Sistem membuat invoice PDF dengan kode verifikasi kriptografi.
20. Orang tua mengunduh invoice.
21. Riwayat dan kalender pembayaran diperbarui.
22. Proses selesai.

JENIS TAGIHAN

Sediakan tiga kategori utama:

1. SPP bulanan.
2. Biaya kegiatan sekolah.
3. Biaya gedung atau pengembangan sekolah.

Setiap tagihan menampilkan:

* Nama tagihan.
* Nama siswa.
* Nomor Induk Siswa.
* Kelas.
* Tahun ajaran.
* Periode pembayaran.
* Nominal awal.
* Potongan beasiswa atau bantuan jika ada.
* Denda jika berlaku.
* Total pembayaran.
* Tanggal terbit.
* Tanggal jatuh tempo.
* Status pembayaran.
* Kebijakan pembayaran.
* Pihak yang menyetujui biaya.
* Tombol “Bayar Sekarang”.

PERSONALISASI AKUN

Pada halaman profil dan beranda, tampilkan:

* Nama orang tua/wali.
* Nama anak.
* Foto atau avatar anak.
* Nomor Induk Siswa.
* Kelas saat ini.
* Tahun ajaran.
* Status siswa aktif.
* Kategori pembiayaan: umum, beasiswa, atau bantuan.
* Ringkasan kewajiban.
* Tagihan terdekat.
* Total yang telah dibayar.
* Tagihan yang belum dibayar.

Jika satu orang tua memiliki lebih dari satu anak, sediakan pemilih profil anak.

Gunakan sapaan personal, misalnya:

“Halo, Ibu Maya.”
“Berikut kewajiban sekolah Aisha untuk Agustus 2026.”

NOTIFIKASI AWAL SEMESTER

Pada awal semester, kirim satu notifikasi ringkasan:

“Informasi Kewajiban Semester Baru”

“Tagihan sekolah untuk Semester Ganjil Tahun Ajaran 2026/2027 telah tersedia. Lihat rincian SPP, biaya kegiatan, biaya gedung, serta kalender pembayaran Aisha.”

Tombol:

“Lihat Kewajiban”

Halaman ringkasan semester menampilkan:

* Total kewajiban semester.
* SPP bulanan.
* Biaya kegiatan.
* Biaya gedung.
* Potongan atau bantuan.
* Kalender jatuh tempo.
* Agenda sekolah yang membutuhkan biaya.

NOTIFIKASI BULANAN

Pada awal setiap bulan, sistem mengirim notifikasi melalui WhatsApp dan aplikasi.

Contoh:

“Pembayaran Agustus Telah Tersedia”

“Halo, Ibu Maya. Saat ini telah memasuki bulan Agustus. Pembayaran SPP Aisha sebesar Rp750.000 dapat dilakukan paling lambat 10 Agustus 2026.”

Tombol:

“Lihat dan Bayar”

ALUR PEMBAYARAN

Setelah memilih “Bayar Sekarang”, tampilkan metode:

1. QRIS.
2. Transfer Virtual Account.
3. Tunai melalui tata usaha.

ALUR QRIS

1. Orang tua memilih QRIS.
2. Sistem menampilkan kode QR.
3. Tampilkan jumlah pembayaran dan batas waktu QR.
4. Orang tua melakukan pembayaran.
5. Sistem memverifikasi transaksi.
6. Status berubah menjadi “Pembayaran Berhasil”.
7. Invoice PDF dibuat otomatis.

ALUR TRANSFER

1. Orang tua memilih bank.
2. Sistem menampilkan nomor Virtual Account.
3. Tampilkan jumlah yang harus dibayar.
4. Orang tua menyalin nomor Virtual Account.
5. Sistem menerima konfirmasi pembayaran.
6. Status berubah menjadi “Pembayaran Berhasil”.
7. Invoice PDF dibuat otomatis.

ALUR PEMBAYARAN TUNAI

1. Orang tua memilih “Tunai melalui Tata Usaha”.
2. Sistem menampilkan jadwal operasional tata usaha.
3. Orang tua dapat membuat jadwal kunjungan.
4. Petugas tata usaha menerima pembayaran.
5. Petugas memasukkan atau mengonfirmasi transaksi.
6. Status berubah menjadi “Lunas”.
7. Invoice PDF dibuat otomatis.

INVOICE PDF

Setelah pembayaran berhasil, sistem menghasilkan invoice PDF resmi yang memuat:

* Logo dan nama sekolah.
* Nomor invoice.
* Nama orang tua/wali.
* Nama siswa.
* Nomor Induk Siswa.
* Kelas.
* Jenis pembayaran.
* Periode pembayaran.
* Nominal pembayaran.
* Potongan bantuan jika berlaku.
* Metode pembayaran.
* Tanggal dan waktu transaksi.
* Status “Lunas”.
* Kode QR verifikasi.
* Hash atau kode kriptografi dokumen.
* Tanda tangan digital sekolah.
* Keterangan bahwa keaslian invoice dapat diverifikasi.

Tambahkan tombol:

* “Unduh PDF”
* “Bagikan Invoice”
* “Verifikasi Invoice”

Invoice tidak boleh menampilkan kategori beasiswa atau bantuan jika informasi tersebut tidak diperlukan pada bukti pembayaran. Cukup tampilkan potongan pembayaran secara netral.

ALUR PENGINGAT DAN PERINGATAN DINI

Buatkan sistem pengingat bertingkat.

TINGKAT 0 — INFORMASI AWAL SEMESTER

Waktu:
Awal semester.

Isi:
Ringkasan seluruh kewajiban semester dan kalender pembayaran.

TINGKAT 1 — PENGINGAT BULANAN

Waktu:
Awal bulan.

Isi:
Pemberitahuan bahwa tagihan bulanan telah tersedia.

Contoh:

“Pembayaran SPP Agustus telah tersedia dan dapat dibayarkan paling lambat 10 Agustus 2026.”

TINGKAT 2 — PENGINGAT PERTENGAHAN BULAN

Kondisi:
Pembayaran belum diterima hingga pertengahan bulan.

Contoh:

“Pengingat Pembayaran”

“Kami belum menerima pembayaran SPP Agustus untuk Aisha. Silakan melihat rincian tagihan atau menghubungi tata usaha apabila membutuhkan bantuan.”

Tombol:

* “Bayar Sekarang”
* “Hubungi Tata Usaha”

TINGKAT 3 — REKAP TIGA BULAN

Kondisi:
Terdapat pembayaran yang belum diselesaikan selama tiga bulan.

Contoh:

“Rekap Kewajiban Memerlukan Perhatian”

“Terdapat kewajiban pembayaran selama tiga periode yang belum diselesaikan. Silakan meninjau rincian atau menjadwalkan konsultasi dengan tata usaha.”

Tombol:

* “Lihat Rekap”
* “Atur Pertemuan”

Gunakan kalimat yang netral, empatik, dan tidak menyalahkan orang tua maupun siswa.

TINGKAT 4 — PERINGATAN TINDAK LANJUT

Kondisi:
Tidak terdapat pembayaran selama tiga bulan dan belum ada tindak lanjut.

Kanal:
WhatsApp dan notifikasi aplikasi.

Status aplikasi:
“Tindak Lanjut Diperlukan”

Isi:

“Kami memahami setiap keluarga dapat menghadapi kondisi yang berbeda. Mohon menjadwalkan pertemuan dengan bagian administrasi untuk membahas penyelesaian kewajiban sekolah.”

Tombol utama:

“Jadwalkan Pertemuan”

Jangan langsung memberikan sanksi otomatis. Keputusan mengenai keringanan, penjadwalan ulang, bantuan, atau konsekuensi hanya dapat dilakukan oleh pihak sekolah yang berwenang.

FITUR PENJADWALAN PERTEMUAN

Buat halaman “Jadwalkan Pertemuan” dengan:

* Pilihan topik pertemuan.
* Pilihan pembayaran atau tagihan yang ingin dibahas.
* Pilihan tanggal.
* Pilihan waktu.
* Pilihan metode pertemuan: daring atau tatap muka.
* Lokasi pertemuan jika tatap muka.
* Tautan konferensi video jika daring.
* Kolom catatan.
* Tombol “Konfirmasi Jadwal”.

Topik pertemuan:

* Klarifikasi tagihan.
* Konfirmasi pembayaran.
* Permohonan keringanan.
* Informasi beasiswa atau bantuan.
* Pembayaran tunai.
* Kendala lainnya.

Setelah dikonfirmasi, tampilkan:

“Pertemuan Berhasil Dijadwalkan”

Sediakan tombol:

* “Tambahkan ke Kalender”
* “Ubah Jadwal”
* “Batalkan Pertemuan”

FITUR KALENDER

Buat kalender bulanan dan tahunan yang menampilkan:

* Tanggal pembayaran SPP.
* Jatuh tempo biaya gedung.
* Jadwal pembayaran kegiatan.
* Agenda sekolah yang membutuhkan biaya.
* Jadwal pertemuan dengan tata usaha.
* Hari libur sekolah.
* Status pembayaran per tanggal.

Gunakan penanda warna:

* Hijau: sudah dibayar.
* Ungu: pembayaran mendatang.
* Kuning: segera jatuh tempo.
* Oranye: perlu perhatian.
* Merah: tunggakan kritis.
* Biru: agenda sekolah.

Saat tanggal dipilih, tampilkan:

* Nama agenda atau tagihan.
* Penjelasan.
* Nominal.
* Jatuh tempo.
* Status persetujuan komite sekolah.
* Tombol “Lihat Rincian”.
* Tombol “Bayar Sekarang”, jika relevan.

AGENDA SEKOLAH BERBAYAR

Setiap agenda sekolah menampilkan:

* Nama kegiatan.
* Deskripsi kegiatan.
* Tanggal kegiatan.
* Peserta kegiatan.
* Nominal biaya.
* Batas pembayaran.
* Status persetujuan komite sekolah.
* Dokumen atau berita acara persetujuan.
* Status pembayaran.
* Informasi apakah biaya wajib atau opsional.

Contoh:

“Kunjungan Edukasi Semester Ganjil”

“Agenda telah disepakati oleh Komite Sekolah pada 15 Juli 2026.”

Tombol:

“Lihat Rincian Biaya”

DAFTAR HALAMAN PROTOTYPE

Buat minimal 20 layar aplikasi seluler:

1. Layar pembuka CERDAS.
2. Aktivasi akun.
3. Verifikasi OTP.
4. Konfirmasi data orang tua.
5. Konfirmasi profil anak.
6. Beranda orang tua.
7. Pemilih profil anak.
8. Ringkasan kewajiban semester.
9. Daftar semua tagihan.
10. Rincian tagihan.
11. Kalender pembayaran dan agenda.
12. Pilihan metode pembayaran.
13. Pembayaran QRIS.
14. Pembayaran transfer Virtual Account.
15. Pembayaran tunai melalui tata usaha.
16. Pembayaran berhasil.
17. Invoice dan bukti pembayaran.
18. Pusat notifikasi.
19. Rekap tunggakan tiga bulan.
20. Penjadwalan pertemuan.
21. Konfirmasi jadwal pertemuan.
22. Riwayat pembayaran.
23. Profil dan demografi siswa.
24. Pusat bantuan.

NAVIGASI UTAMA APLIKASI

Gunakan navigasi bawah dengan lima menu:

1. Beranda.
2. Tagihan.
3. Kalender.
4. Riwayat.
5. Profil.

BERANDA ORANG TUA

Tampilkan:

* Sapaan personal.
* Profil anak dan kelas.
* Ringkasan total kewajiban.
* Status pembayaran bulan berjalan.
* Tagihan terdekat.
* Peringatan yang perlu diperhatikan.
* Kalender mini.
* Agenda sekolah mendatang.
* Tombol “Bayar Sekarang”.
* Tombol “Lihat Semua Tagihan”.

USER JOURNEY ORANG TUA

Buatkan visual user journey dengan tahapan:

1. Anak diterima dan mendapatkan Nomor Induk Siswa.
2. Orang tua menerima aktivasi akun.
3. Orang tua memverifikasi data.
4. Orang tua menerima informasi awal semester.
5. Orang tua melihat kalender kewajiban.
6. Orang tua menerima notifikasi bulanan.
7. Orang tua membuka rincian tagihan.
8. Orang tua memilih metode pembayaran.
9. Orang tua menyelesaikan pembayaran.
10. Orang tua menerima invoice PDF.
11. Riwayat dan kalender diperbarui.
12. Jika belum membayar, orang tua menerima pengingat pertengahan bulan.
13. Jika tiga bulan belum membayar, orang tua menerima rekap peringatan.
14. Orang tua menjadwalkan konsultasi.
15. Orang tua dan tata usaha menyepakati tindak lanjut.
16. Status kewajiban diperbarui.

Untuk setiap tahap user journey, tampilkan:

* Aktivitas pengguna.
* Kanal interaksi.
* Tujuan pengguna.
* Pikiran pengguna.
* Kondisi emosional.
* Kendala.
* Peluang perbaikan.
* Respons sistem.

USER JOURNEY TATA USAHA

Buatkan user journey tata usaha:

1. Mendaftarkan siswa dan orang tua.
2. Menetapkan kategori pembiayaan.
3. Membuat struktur tagihan.
4. Menerbitkan tagihan semester.
5. Memantau pengiriman notifikasi.
6. Memeriksa pembayaran.
7. Memverifikasi pembayaran tunai.
8. Melakukan rekonsiliasi.
9. Memantau tunggakan.
10. Meninjau peringatan tiga bulan.
11. Menerima permintaan pertemuan.
12. Melakukan konsultasi.
13. Mencatat hasil tindak lanjut.
14. Memperbarui status pembayaran atau bantuan.
15. Membuat laporan kepada kepala sekolah.

OUTPUT VISUAL FLOW PROCESS

Buat diagram dengan empat jalur pengguna:

* Sistem CERDAS.
* Orang tua/wali.
* Tata usaha.
* Gerbang pembayaran.

Gunakan keputusan bercabang:

“Apakah pembayaran dilakukan sebelum jatuh tempo?”

Jika “Ya”:
Pembayaran → Verifikasi → Invoice PDF → Status Lunas → Selesai.

Jika “Tidak”:
Pengingat pertengahan bulan → Periksa pembayaran.

Jika tetap belum dibayar selama tiga bulan:
Rekap tunggakan → Peringatan tindak lanjut → Jadwalkan pertemuan → Konsultasi dengan tata usaha → Kesepakatan tindak lanjut → Perbarui status.

Sediakan kemungkinan hasil konsultasi:

* Pembayaran langsung.
* Penjadwalan pembayaran sesuai kebijakan sekolah.
* Pengajuan beasiswa atau bantuan.
* Klarifikasi kesalahan data.
* Tindak lanjut kebijakan sekolah.

INTERAKSI PROTOTYPE

Hubungkan seluruh tombol utama agar dapat diklik:

* Notifikasi menuju rincian tagihan.
* “Bayar Sekarang” menuju metode pembayaran.
* QRIS atau transfer menuju status pembayaran.
* Pembayaran berhasil menuju invoice.
* Tanggal kalender menuju rincian agenda.
* Peringatan tiga bulan menuju rekap tunggakan.
* “Atur Pertemuan” menuju kalender penjadwalan.
* Jadwal berhasil menuju rincian pertemuan.
* Navigasi bawah terhubung ke seluruh halaman utama.

Buat prototype yang realistis, konsisten, siap diuji kepada orang tua/wali, dan menunjukkan alur normal maupun alur pengecualian ketika pembayaran terlambat.
