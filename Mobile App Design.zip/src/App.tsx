import { useState } from "react";
import SplashScreen from "./screens/SplashScreen";
import LandingScreen from "./screens/LandingScreen";
import ActivasiScreen from "./screens/ActivasiScreen";
import OTPScreen from "./screens/OTPScreen";
import KonfirmasiOrangTuaScreen from "./screens/KonfirmasiOrangTuaScreen";
import KonfirmasiAnakScreen from "./screens/KonfirmasiAnakScreen";
import BerandaScreen from "./screens/BerandaScreen";
import PilihAnakScreen from "./screens/PilihAnakScreen";
import RingkasanSemesterScreen from "./screens/RingkasanSemesterScreen";
import DaftarTagihanScreen from "./screens/DaftarTagihanScreen";
import RincianTagihanScreen from "./screens/RincianTagihanScreen";
import KalenderScreen from "./screens/KalenderScreen";
import MetodePembayaranScreen from "./screens/MetodePembayaranScreen";
import QRISScreen from "./screens/QRISScreen";
import VirtualAccountScreen from "./screens/VirtualAccountScreen";
import TunaiScreen from "./screens/TunaiScreen";
import PembayaranBerhasilScreen from "./screens/PembayaranBerhasilScreen";
import InvoiceScreen from "./screens/InvoiceScreen";
import NotifikasiScreen from "./screens/NotifikasiScreen";
import RekapTunggakanScreen from "./screens/RekapTunggakanScreen";
import JadwalkanPertemuanScreen from "./screens/JadwalkanPertemuanScreen";
import KonfirmasiPertemuanScreen from "./screens/KonfirmasiPertemuanScreen";
import RiwayatScreen from "./screens/RiwayatScreen";
import ProfilScreen from "./screens/ProfilScreen";
import PusatBantuanScreen from "./screens/PusatBantuanScreen";

export type Screen =
  | "splash"
  | "landing"
  | "aktivasi"
  | "otp"
  | "konfirmasi-ortu"
  | "konfirmasi-anak"
  | "beranda"
  | "pilih-anak"
  | "ringkasan-semester"
  | "daftar-tagihan"
  | "rincian-tagihan"
  | "kalender"
  | "metode-pembayaran"
  | "qris"
  | "virtual-account"
  | "tunai"
  | "pembayaran-berhasil"
  | "invoice"
  | "notifikasi"
  | "rekap-tunggakan"
  | "jadwalkan-pertemuan"
  | "konfirmasi-pertemuan"
  | "riwayat"
  | "profil"
  | "pusat-bantuan";

export type NavTab = "beranda" | "tagihan" | "kalender" | "riwayat" | "profil";

export default function App() {
  const [screen, setScreen] = useState<Screen>("splash");
  const [activeNav, setActiveNav] = useState<NavTab>("beranda");

  const navigate = (s: Screen) => {
    setScreen(s);
    if (s === "beranda") setActiveNav("beranda");
    else if (s === "daftar-tagihan" || s === "rincian-tagihan") setActiveNav("tagihan");
    else if (s === "kalender") setActiveNav("kalender");
    else if (s === "riwayat") setActiveNav("riwayat");
    else if (s === "profil") setActiveNav("profil");
  };

  const navTab = (tab: NavTab) => {
    setActiveNav(tab);
    if (tab === "beranda") setScreen("beranda");
    else if (tab === "tagihan") setScreen("daftar-tagihan");
    else if (tab === "kalender") setScreen("kalender");
    else if (tab === "riwayat") setScreen("riwayat");
    else if (tab === "profil") setScreen("profil");
  };

  const showNav = [
    "beranda","pilih-anak","ringkasan-semester","daftar-tagihan",
    "rincian-tagihan","kalender","riwayat","profil","notifikasi",
    "rekap-tunggakan","pusat-bantuan","riwayat",
  ].includes(screen);

  const screenProps = { navigate };

  return (
    <div className="min-h-full flex items-center justify-center bg-gradient-to-br from-purple-100 via-violet-50 to-indigo-100 sm:p-4 sm:py-8">
      <div className="relative bg-white sm:rounded-[32px] overflow-hidden flex flex-col w-full h-screen sm:h-[844px] sm:w-[390px] sm:border-[8px] sm:border-gray-900 sm:shadow-[0_40px_100px_rgba(109,40,217,0.25)]">
        {/* Screen Content */}
        <div className="flex-1 overflow-hidden relative">
          <div className="phone-screen h-full overflow-y-auto">
            {screen === "splash" && <SplashScreen {...screenProps} />}
            {screen === "landing" && <LandingScreen {...screenProps} />}
            {screen === "aktivasi" && <ActivasiScreen {...screenProps} />}
            {screen === "otp" && <OTPScreen {...screenProps} />}
            {screen === "konfirmasi-ortu" && <KonfirmasiOrangTuaScreen {...screenProps} />}
            {screen === "konfirmasi-anak" && <KonfirmasiAnakScreen {...screenProps} />}
            {screen === "beranda" && <BerandaScreen {...screenProps} />}
            {screen === "pilih-anak" && <PilihAnakScreen {...screenProps} />}
            {screen === "ringkasan-semester" && <RingkasanSemesterScreen {...screenProps} />}
            {screen === "daftar-tagihan" && <DaftarTagihanScreen {...screenProps} />}
            {screen === "rincian-tagihan" && <RincianTagihanScreen {...screenProps} />}
            {screen === "kalender" && <KalenderScreen {...screenProps} />}
            {screen === "metode-pembayaran" && <MetodePembayaranScreen {...screenProps} />}
            {screen === "qris" && <QRISScreen {...screenProps} />}
            {screen === "virtual-account" && <VirtualAccountScreen {...screenProps} />}
            {screen === "tunai" && <TunaiScreen {...screenProps} />}
            {screen === "pembayaran-berhasil" && <PembayaranBerhasilScreen {...screenProps} />}
            {screen === "invoice" && <InvoiceScreen {...screenProps} />}
            {screen === "notifikasi" && <NotifikasiScreen {...screenProps} />}
            {screen === "rekap-tunggakan" && <RekapTunggakanScreen {...screenProps} />}
            {screen === "jadwalkan-pertemuan" && <JadwalkanPertemuanScreen {...screenProps} />}
            {screen === "konfirmasi-pertemuan" && <KonfirmasiPertemuanScreen {...screenProps} />}
            {screen === "riwayat" && <RiwayatScreen {...screenProps} />}
            {screen === "profil" && <ProfilScreen {...screenProps} />}
            {screen === "pusat-bantuan" && <PusatBantuanScreen {...screenProps} />}
          </div>
        </div>

        {/* Bottom Nav */}
        {showNav && (
          <div className="flex-none bg-white border-t border-gray-100 pb-5 pt-2 z-20">
            <div className="flex items-center justify-around">
              {[
                { tab: "beranda" as NavTab, label: "Beranda", icon: HomeIcon },
                { tab: "tagihan" as NavTab, label: "Tagihan", icon: BillIcon },
                { tab: "kalender" as NavTab, label: "Kalender", icon: CalIcon },
                { tab: "riwayat" as NavTab, label: "Riwayat", icon: HistIcon },
                { tab: "profil" as NavTab, label: "Profil", icon: UserIcon },
              ].map(({ tab, label, icon: Icon }) => {
                const active = activeNav === tab;
                return (
                  <button
                    key={tab}
                    onClick={() => navTab(tab)}
                    className="flex flex-col items-center gap-0.5 min-w-[56px]"
                  >
                    <div className={`p-1.5 rounded-xl transition-all ${active ? "bg-purple-100" : ""}`}>
                      <Icon active={active} />
                    </div>
                    <span className={`text-[10px] font-medium ${active ? "text-purple-700" : "text-gray-400"}`}>
                      {label}
                    </span>
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

function HomeIcon({ active }: { active: boolean }) {
  return (
    <svg className={`w-5 h-5 ${active ? "text-purple-700" : "text-gray-400"}`} fill={active ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M3 9.5L12 3l9 6.5V20a1 1 0 01-1 1H4a1 1 0 01-1-1V9.5z" strokeLinecap="round" strokeLinejoin="round"/>
      <path d="M9 21V12h6v9" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
function BillIcon({ active }: { active: boolean }) {
  return (
    <svg className={`w-5 h-5 ${active ? "text-purple-700" : "text-gray-400"}`} fill={active ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect x="4" y="2" width="16" height="20" rx="2" strokeLinecap="round"/>
      <path d="M8 7h8M8 11h8M8 15h5" strokeLinecap="round"/>
    </svg>
  );
}
function CalIcon({ active }: { active: boolean }) {
  return (
    <svg className={`w-5 h-5 ${active ? "text-purple-700" : "text-gray-400"}`} fill={active ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <rect x="3" y="4" width="18" height="18" rx="2" strokeLinecap="round"/>
      <path d="M16 2v4M8 2v4M3 10h18" strokeLinecap="round"/>
      {active && <circle cx="8" cy="15" r="1.5" fill="currentColor"/>}
      {active && <circle cx="12" cy="15" r="1.5" fill="currentColor"/>}
    </svg>
  );
}
function HistIcon({ active }: { active: boolean }) {
  return (
    <svg className={`w-5 h-5 ${active ? "text-purple-700" : "text-gray-400"}`} fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <path d="M12 8v4l3 3" strokeLinecap="round"/>
      <path d="M3.05 11a9 9 0 1 0 .5-3" strokeLinecap="round"/>
      <path d="M3 4v4h4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}
function UserIcon({ active }: { active: boolean }) {
  return (
    <svg className={`w-5 h-5 ${active ? "text-purple-700" : "text-gray-400"}`} fill={active ? "currentColor" : "none"} stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
      <circle cx="12" cy="8" r="4"/>
      <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7" strokeLinecap="round"/>
    </svg>
  );
}
